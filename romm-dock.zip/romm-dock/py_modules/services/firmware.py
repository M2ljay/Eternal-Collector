"""FirmwareService — BIOS/firmware registry orchestration.

Owns the BIOS registry lifecycle and every status-bearing query the
QAM panel runs against it: presence checks per system or core,
deletion, and reads of cached server-side firmware metadata. Raw
filesystem I/O is delegated to the ``FirmwareFileStore`` Protocol and
HTTP traffic flows through ``RommFirmwareApi``; the registry shape,
caching policy, and per-core filtering logic remain this service's
responsibility.
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import asdict, dataclass
from typing import TYPE_CHECKING, Any

from domain import firmware_paths

# EmuDeck for Windows runs PS2 games on standalone PCSX2, whose BIOS folder is
# the BIOS root itself (``Bios = C:\Emulation\bios`` in PCSX2.ini), not the
# RetroArch-core subfolder the registry names. Registry paths under these
# prefixes are flattened into the root on Windows; everything else keeps the
# RetroArch system-folder layout, which is what EmuDeck's RetroArch reads.
_WINDOWS_FLATTENED_FIRMWARE_PREFIXES = ("pcsx2/bios/",)


def _platform_firmware_path(firmware_path: str) -> str:
    if sys.platform == "win32":
        for prefix in _WINDOWS_FLATTENED_FIRMWARE_PREFIXES:
            if firmware_path.lower().startswith(prefix):
                return firmware_path[len(prefix) :]
    return firmware_path
from domain.bios import collect_firmware_status, compute_bios_level, format_bios_status
from domain.bios_file import BiosFile
from domain.emulator_commands import label_to_invocation, options_to_payload, select_default_option
from domain.firmware_cache import FirmwareCacheEntry
from domain.xemu_config import compute_xemu_alignment
from lib.errors import error_response
from lib.list_result import ErrorCode
from lib.path_safety import PathTraversalError, safe_join

if TYPE_CHECKING:
    import asyncio
    import logging
    from collections.abc import Callable

    from services.protocols import (
        Clock,
        CoreInfoProvider,
        FirmwareFileStore,
        LauncherPaths,
        PlatformCoreReader,
        RommFirmwareApi,
        SystemResolver,
        UnitOfWorkFactory,
        XemuConfigReader,
    )

_FIRMWARE_CACHE_TTL = 3600  # 1 hour


@dataclass(frozen=True)
class FirmwareServiceConfig:
    """Frozen wiring bundle handed to ``FirmwareService.__init__``.

    Holds the API adapter, runtime infrastructure, Protocol-typed file
    adapters, the SQLite Unit-of-Work factory, and the provider callables
    FirmwareService needs at construction time. ``core_info``/
    ``active_backend_id`` are the ACTIVE launcher backend's emulator-selection
    catalogue and its id (issue #918's per-backend picker follow-up) — the
    System page's active-core display and BIOS filter follow whichever
    backend is currently selected, the same as the picker menus. Decomposes
    the ctor so a new dependency does not push past the S107 parameter-count
    limit.
    """

    romm_api: RommFirmwareApi
    loop: asyncio.AbstractEventLoop
    logger: logging.Logger
    plugin_dir: str
    clock: Clock
    firmware_file_store: FirmwareFileStore
    launcher_paths: LauncherPaths
    core_info: CoreInfoProvider
    active_backend_id: Callable[[], str]
    resolve_system: SystemResolver
    platform_core_reader: PlatformCoreReader
    uow_factory: UnitOfWorkFactory
    xemu_config: XemuConfigReader


class FirmwareService:
    """BIOS/firmware management: registry, status, downloads, deletion."""

    def __init__(
        self,
        *,
        config: FirmwareServiceConfig,
    ) -> None:
        self._romm_api = config.romm_api
        self._loop = config.loop
        self._logger = config.logger
        self._plugin_dir = config.plugin_dir
        self._clock = config.clock
        self._firmware_file_store = config.firmware_file_store
        self._launcher_paths = config.launcher_paths
        self._core_info = config.core_info
        self._active_backend_id = config.active_backend_id
        self._resolve_system = config.resolve_system
        self._platform_core_reader = config.platform_core_reader
        self._uow_factory = config.uow_factory
        self._xemu_config = config.xemu_config
        self._bios_registry: dict[str, Any] = {}
        self._bios_files_index: dict[str, dict[str, Any]] | None = None
        self._bios_files_by_hash: dict[str, dict[str, Any]] = {}
        self._firmware_cache: list[dict[str, Any]] | None = None
        self._firmware_cache_epoch: float = 0
        self._restore_firmware_cache()

    @property
    def bios_files_index(self) -> dict[str, dict[str, Any]]:
        """Flat reverse index of BIOS files: {filename: entry_data}.

        Raises ``RuntimeError`` if accessed before ``load_bios_registry()`` —
        a silent empty dict at startup masks order-sensitive wiring bugs.
        """
        if self._bios_files_index is None:
            raise RuntimeError("firmware registry not loaded — call load_bios_registry() first")
        return self._bios_files_index

    # ── Registry loading ─────────────────────────────────────

    def load_bios_registry(self) -> None:
        self._bios_registry = {}
        self._bios_files_index = {}
        self._bios_files_by_hash = {}
        self._load_registry_file("bios_registry.json")
        # Plugin-owned supplement for standalone (non-libretro) emulators the
        # vendored, emu-atlas-generated bios_registry.json does not cover
        # (xemu is not a libretro core). Same shape, merged into the same
        # in-memory registry so every consumer treats it identically —
        # see defaults/README.md.
        self._load_registry_file("xbox_bios_registry.json", merge=True)
        # Same for standalone PCSX2: the vendored ps2 entries describe only the
        # libretro core's folder, so real BIOS dumps never resolve without it.
        self._load_registry_file("ps2_bios_registry.json", merge=True)
        self._bios_files_by_hash = {
            entry["md5"].lower(): entry for entry in self._bios_files_index.values() if entry.get("md5")
        }

    def _load_registry_file(self, filename: str, *, merge: bool = False) -> None:
        """Load one registry JSON file and fold its platforms into the shared index.

        ``merge=False`` replaces ``self._bios_registry`` wholesale (the primary,
        vendored registry); ``merge=True`` folds the file's platforms into the
        existing registry instead, for the plugin-owned supplement loaded after
        it. A missing supplement file is not an error — only the primary
        registry warns on absence.
        """
        # Check plugin root first (Decky CLI moves defaults/ contents to root),
        # then defaults/ subdirectory (dev deploys via mise run deploy)
        root_path = os.path.join(self._plugin_dir, filename)
        defaults_path = os.path.join(self._plugin_dir, "defaults", filename)
        registry_path = root_path if self._firmware_file_store.exists(root_path) else defaults_path
        # load_bios_registry() always sets this to {} immediately before calling
        # here; the guard is for the type checker, which cannot narrow a field
        # set by a different method than the one reading it.
        if self._bios_files_index is None:
            self._bios_files_index = {}
        index = self._bios_files_index
        try:
            data = self._firmware_file_store.read_bytes(registry_path)
            registry = json.loads(data)
            if merge:
                # File-level merge: a supplement may add entries to a platform
                # the vendored registry already lists (ps2) without dropping
                # that platform's libretro entries.
                merged = self._bios_registry.setdefault("platforms", {})
                for platform, files in registry.get("platforms", {}).items():
                    merged.setdefault(platform, {}).update(files)
            else:
                self._bios_registry = registry
            for platform, files in registry.get("platforms", {}).items():
                for name, entry in files.items():
                    index[name] = {**entry, "platform": platform}
        except FileNotFoundError:
            if not merge:
                self._logger.warning(f"{filename} not found, registry enrichment disabled")
        except Exception as e:
            self._logger.error(f"Failed to load {filename}: {e}")

    # ── Internal helpers ─────────────────────────────────────

    def _resolve_index_entry(self, file_name: str, md5: str = "") -> dict[str, Any] | None:
        """Look up ``bios_files_index`` by exact name, falling back to content hash.

        A server file whose name is not a registry key — a differently-named
        BIOS dump, most relevantly for xemu's non-libretro entries — still
        resolves when its md5 matches a known one, via ``_bios_files_by_hash``.
        """
        entry = self.bios_files_index.get(file_name)
        if entry is not None:
            return entry
        if not md5:
            return None
        return self._bios_files_by_hash.get(md5.lower())

    def _enrich_firmware_file(self, file_dict, core_so=None):
        entry = self._resolve_index_entry(file_dict.get("file_name", ""), file_dict.get("md5", ""))
        if entry:
            # Use per-core required value if active core is known
            if core_so and "cores" in entry and core_so in entry["cores"]:
                is_required = entry["cores"][core_so]["required"]
            else:
                is_required = entry.get("required", True)
            required = is_required
            description = entry.get("description", file_dict.get("file_name", ""))
            classification = "required" if is_required else "optional"
        else:
            # Unknown file: not in registry, don't count as required
            required = False
            description = file_dict.get("file_name", "")
            classification = "unknown"
        file_md5 = file_dict.get("md5", "")
        registry_md5 = entry.get("md5", "") if entry else ""
        hash_valid = file_md5.lower() == registry_md5.lower() if file_md5 and registry_md5 else None
        return {
            **file_dict,
            "required": required,
            "description": description,
            "classification": classification,
            "hash_valid": hash_valid,
        }

    def _firmware_dest_path(self, firmware):
        """Determine local destination path for a firmware file.

        Uses firmware_path from bios_registry.json for correct subdirectory
        placement (e.g. dc/dc_boot.bin). Falls back to flat in bios root
        for files not in the registry.

        Both branches go through ``safe_join`` so a server-supplied
        ``file_name`` (and, defensively, the static registry path) cannot
        escape the BIOS directory via ``..`` or an absolute path. Raises
        :class:`PathTraversalError` on an escape attempt — the write path
        (``download_firmware``) turns that into a canonical failure; the
        read paths skip the poisoned entry.
        """
        bios_base = self._launcher_paths.bios_path()
        file_name = firmware.get("file_name", "")
        reg_entry = self._resolve_index_entry(file_name, firmware.get("md5_hash", ""))
        if reg_entry and reg_entry.get("firmware_path"):
            return safe_join(bios_base, _platform_firmware_path(reg_entry["firmware_path"]))
        return safe_join(bios_base, file_name)

    def _safe_firmware_dest_path(self, firmware) -> str | None:
        """Read-path wrapper for ``_firmware_dest_path`` — ``None`` on a poisoned entry.

        The status queries (``check_platform_bios``, the System-page group)
        only need to know whether a firmware file is downloaded; a server
        entry whose ``file_name`` attempts path traversal cannot be on
        disk, so it is logged and dropped from the listing instead of
        crashing the whole panel. The write path keeps the raising
        ``_firmware_dest_path`` so a download attempt fails closed.
        """
        try:
            return self._firmware_dest_path(firmware)
        except PathTraversalError as e:
            self._logger.warning(f"Skipping firmware with unsafe file name: {e}")
            return None

    def _safe_registry_dest_path(self, firmware_path: str) -> str | None:
        """Containment-check a registry-relative BIOS path — ``None`` on a poisoned entry.

        The registry read paths (``_group_registry_firmware`` and the
        offline System-page fallback) resolve a ``firmware_path`` that
        falls back to the server-supplied ``file_name`` when absent, so the
        raw join can be steered outside the BIOS directory by a compromised
        server. These are existence-check reads (not writes), so a rejected
        path is logged and skipped — the panel stays up minus the poisoned
        entry, mirroring ``_safe_firmware_dest_path``.
        """
        bios_base = self._launcher_paths.bios_path()
        try:
            return safe_join(bios_base, _platform_firmware_path(firmware_path))
        except PathTraversalError as e:
            self._logger.warning(f"Skipping registry firmware with unsafe path: {e}")
            return None

    def _build_firmware_status_items(self, firmware_iter) -> list[dict[str, Any]]:
        """Build ``collect_firmware_status`` items, dropping traversal-poisoned entries.

        Each item carries the resolved ``dest`` and its ``downloaded``
        flag. A firmware entry whose ``file_name`` fails the path-safety
        check resolves to ``None`` and is skipped (logged in
        ``_safe_firmware_dest_path``) so a single malicious entry cannot
        crash the status query.
        """
        items: list[dict[str, Any]] = []
        for fw in firmware_iter:
            dest = self._safe_firmware_dest_path(fw)
            if dest is None:
                continue
            items.append(
                {
                    "file_name": fw.get("file_name", ""),
                    "downloaded": self._firmware_file_store.exists(dest),
                    "dest": dest,
                    "md5": fw.get("md5_hash", ""),
                }
            )
        return items

    # ── Firmware list cache ─────────────────────────────────

    def _restore_firmware_cache(self) -> None:
        """Rebuild the in-memory firmware cache from the SQLite cache table.

        The ``firmware_cache`` table is a thin record per ADR-0003 — it carries
        the already-parsed ``platform_slug`` and ``name`` but not the raw RomM
        ``file_path`` or ``md5_hash``. We synthesize a ``bios/<slug>/<name>``
        ``file_path`` that round-trips through ``parse_firmware_slug`` so the
        cache-only consumers (``check_platform_bios_cached``) keep working after
        a restart; ``md5_hash`` is intentionally absent (display-only).
        """
        try:
            with self._uow_factory() as uow:
                entries = list(uow.firmware_cache.iter_all())
                epoch = uow.firmware_cache.get_cache_epoch()
        except Exception as e:
            self._logger.warning(f"Failed to load firmware cache from DB: {e}")
            return

        if not entries or epoch is None:
            return

        self._firmware_cache = [self._entry_to_firmware_dict(entry) for entry in entries]
        self._firmware_cache_epoch = epoch
        self._logger.info("Restored firmware cache from DB (%d items)", len(entries))

    @staticmethod
    def _entry_to_firmware_dict(entry: FirmwareCacheEntry) -> dict[str, Any]:
        """Reconstruct an in-memory firmware dict from a thin cache aggregate."""
        return {
            "id": entry.id,
            "file_name": entry.name,
            "file_path": f"bios/{entry.platform_slug}/{entry.name}",
            "file_size_bytes": entry.file_size_bytes,
            "md5_hash": "",
        }

    def _persist_firmware_cache(self) -> None:
        """Replace the SQLite firmware cache with the current in-memory listing.

        Maps each raw RomM firmware dict to a thin ``FirmwareCacheEntry`` (slug
        pre-parsed from ``file_path``) and writes them wholesale.
        """
        if self._firmware_cache is None:
            return
        entries = [
            FirmwareCacheEntry.cached(
                id=fw.get("id"),
                name=fw.get("file_name", ""),
                platform_slug=firmware_paths.parse_firmware_slug(fw.get("file_path", "")),
                file_size_bytes=fw.get("file_size_bytes", 0),
                cached_at=self._firmware_cache_epoch,
            )
            for fw in self._firmware_cache
        ]
        try:
            with self._uow_factory() as uow:
                uow.firmware_cache.replace_all(entries)
        except Exception as e:
            self._logger.warning(f"Failed to persist firmware cache: {e}")

    def _get_firmware_list(self) -> list[dict[str, Any]]:
        """Return firmware list, using cache if TTL has not expired.

        TTL is checked against the wall-clock cache epoch so a cache
        restored from disk after a plugin restart still expires.

        On HTTP error, falls back to cached data if there is any and RAISES
        otherwise. Returning an empty list instead would be indistinguishable
        from a server that genuinely holds no firmware, and ``check_platform_bios``
        answers a confident "needs none" for that — so the raise is what lets a
        failed fetch be reported as unknown rather than as a negative (#1693).
        """
        now = self._clock.time()
        if self._firmware_cache is not None and (now - self._firmware_cache_epoch) < _FIRMWARE_CACHE_TTL:
            return self._firmware_cache

        try:
            result = self._romm_api.list_firmware()
            self._firmware_cache = result
            self._firmware_cache_epoch = self._clock.time()
            self._persist_firmware_cache()
            return result
        except Exception as e:
            self._logger.warning(f"Failed to fetch firmware list: {e}")
            if self._firmware_cache is not None:
                return self._firmware_cache
            raise

    def invalidate_firmware_cache(self) -> None:
        """Clear cached firmware list so the next call re-fetches."""
        self._firmware_cache = None
        self._firmware_cache_epoch = 0
        try:
            with self._uow_factory() as uow:
                uow.firmware_cache.clear()
        except Exception as e:
            self._logger.warning(f"Failed to clear persisted firmware cache: {e}")

    def _resolve_bios_filter_core(self, system: str, active_core_so: str | None) -> str | None:
        """Return the ``.so`` to filter the firmware list against.

        A non-``None`` ``active_core_so`` is the pre-resolved per-game core (the
        game-detail path runs ``ActiveCoreReader`` upstream) and is used as-is.
        ``None`` is the platform-level callers' "use the system default" signal —
        resolved here via the system-layer ``get_active_core(system)``.
        """
        if active_core_so is not None:
            return active_core_so
        core_so, _ = self._core_info.get_active_core(system)
        return core_so

    def check_platform_bios_cached(self, platform_slug, active_core_so=None):
        """Return BIOS status from in-memory cache only — no HTTP.

        Returns None if the firmware cache is empty (never fetched).
        Includes ``cached_at`` timestamp so the frontend can decide staleness.
        ``active_core_so`` is the pre-resolved core that drives core-aware BIOS
        filtering — it is an INPUT to ``collect_firmware_status``, never served
        back to the UI. ``None`` means "use the system default" (resolved here
        via ``get_active_core(system)``); the per-game game-detail path passes
        the ROM's resolved ``.so`` directly. Core info (active core, available
        cores) reaches the frontend through the dedicated
        ``get_platform_core_info`` path, not this BIOS payload (#923).
        """
        if self._firmware_cache is None:
            return None

        system = self._resolve_system(platform_slug)
        fw_slugs = firmware_paths.resolve_firmware_slugs(platform_slug)
        active_core_so = self._resolve_bios_filter_core(system, active_core_so)

        registry_platform = {}
        for slug in fw_slugs:
            registry_platform.update(self._bios_registry.get("platforms", {}).get(slug, {}))

        items = self._build_firmware_status_items(
            fw for fw in self._firmware_cache if firmware_paths.parse_firmware_slug(fw.get("file_path", "")) in fw_slugs
        )
        files = collect_firmware_status(items, registry_platform, active_core_so)

        if not files:
            return {
                "needs_bios": False,
                "cached_at": self._firmware_cache_epoch,
            }

        server_count = len(files)
        local_count = sum(1 for f in files if f.downloaded)
        active_files = [f for f in files if f.used_by_active]
        required_files = [f for f in active_files if f.classification == "required"]

        return {
            "needs_bios": True,
            "server_count": server_count,
            "local_count": local_count,
            "all_downloaded": local_count >= server_count,
            "required_count": len(required_files),
            "required_downloaded": sum(1 for f in required_files if f.downloaded),
            "unknown_count": sum(1 for f in files if f.classification == "unknown"),
            "known_count": sum(1 for f in files if f.classification != "unknown"),
            "files": [asdict(f) for f in files],
            "cached_at": self._firmware_cache_epoch,
        }

    # ── Public API ───────────────────────────────────────────

    def _group_server_firmware(self, firmware_list):
        """Group server firmware list by platform slug."""
        platforms_map = {}
        for fw in firmware_list:
            platform_slug = firmware_paths.parse_firmware_slug(fw.get("file_path", "")) or "unknown"
            dest = self._safe_firmware_dest_path(fw)
            if dest is None:
                continue
            if platform_slug not in platforms_map:
                platforms_map[platform_slug] = {"platform_slug": platform_slug, "files": []}
            platforms_map[platform_slug]["files"].append(
                {
                    "id": fw.get("id"),
                    "file_name": fw.get("file_name", ""),
                    "size": fw.get("file_size_bytes", 0),
                    "md5": fw.get("md5_hash", ""),
                    "downloaded": self._firmware_file_store.exists(dest),
                }
            )
        return platforms_map

    def _group_registry_firmware(self):
        """Build platform map from bios registry (offline fallback)."""
        platforms_map = {}
        for reg_slug, reg_files in self._bios_registry.get("platforms", {}).items():
            if reg_slug not in platforms_map:
                platforms_map[reg_slug] = {"platform_slug": reg_slug, "files": []}
            for file_name, reg_entry in reg_files.items():
                firmware_path = reg_entry.get("firmware_path", file_name)
                dest = self._safe_registry_dest_path(firmware_path)
                if dest is None:
                    continue
                platforms_map[reg_slug]["files"].append(
                    {
                        "id": None,
                        "file_name": file_name,
                        "size": 0,
                        "md5": reg_entry.get("md5", ""),
                        "downloaded": self._firmware_file_store.exists(dest),
                    }
                )
        return platforms_map

    def _read_synced_slugs(self) -> set[str]:
        """Return platform slugs with at least one ROM bound to a Steam shortcut.

        A bound ROM (``shortcut_app_id`` set) is one that is currently in the
        synced library, covering both platform- and collection-sync. Deselected
        platforms get unbound on the next sync (ADR-0007) and drop out.
        """
        with self._uow_factory() as uow:
            return {
                rom.platform_slug
                for rom in uow.roms.iter_all()
                if rom.platform_slug and rom.shortcut_app_id is not None
            }

    def _enrich_platform_map(self, platforms_map, synced_slugs):
        """Add core info and game-installed flags to each platform entry.

        The core read seams key by the resolved ``system`` (ADR-0010 §2), so
        each entry's raw RomM/BIOS-folder slug is normalized before the
        ``get_active_core`` / ``get_emulator_options`` calls; ``has_games`` and
        the BIOS-folder file lookups stay on the raw slug (their own vocabulary).
        Both calls go through ``core_info`` — the ACTIVE launcher backend's own
        catalogue (issue #918's per-backend picker follow-up) — so the System
        page shows whichever backend is currently selected, exactly like the
        game-detail picker menu. ``active_core`` stays the libretro system
        default *core_so* (the BIOS filter keys on it — the standalone-default
        BIOS accuracy work is deferred by ADR-0020). ``active_core_label`` is
        the resolved **display** label the System-page control shows — the
        per-platform override (``platform_cores``, scoped to the active
        backend) when set and still resolvable, else the active backend's own
        default emulator label, so it reflects a just-applied per-platform pick
        (libretro OR standalone) the same way the game-detail menu does,
        instead of always showing the libretro system default. The
        ``emulators`` list is the full classified picker payload and
        ``emulator_data_available`` flags whether the active backend's
        catalogue was readable.
        """
        backend_id = self._active_backend_id()
        for plat in platforms_map.values():
            slug = plat["platform_slug"]
            system = self._resolve_system(slug)
            core_so, _core_label = self._core_info.get_active_core(system)
            options = self._core_info.get_emulator_options(system)
            plat["active_core"] = core_so
            plat["active_core_label"] = self._resolve_platform_emulator_label(backend_id, slug, options["options"])
            plat["emulators"] = options_to_payload(options["options"])
            plat["emulator_data_available"] = options["available"]
            plat["files"] = [self._enrich_firmware_file(f, core_so=core_so) for f in plat["files"]]
            plat["has_games"] = slug in synced_slugs
            plat["all_downloaded"] = all(f["downloaded"] for f in plat["files"])
            self._set_platform_bios_aggregates(plat, slug)

    def _resolve_platform_emulator_label(self, backend_id: str, platform_slug: str, options: list[Any]) -> str | None:
        """Resolve the System-page active-emulator display label for a platform.

        The platform-level projection of the read-path precedence
        (``ActiveCoreResolver`` without the per-game layer): *backend_id*'s
        own per-platform override label (``settings.json`` ``platform_cores``)
        when it is set and still resolves to a bakeable emulator, else that
        backend's own default emulator label (the first bakeable command). A
        stale/no-longer-installed override degrades to the default — never
        fatal — mirroring the launch-bake resolver so the button and the
        actual launch agree. ``None`` when the platform has no bakeable
        emulator at all (empty menu / catalogue unreadable), which the
        frontend renders as "Default".
        """
        override = self._platform_core_reader.get_platform_core(backend_id, platform_slug)
        if override is not None and label_to_invocation(options, override) is not None:
            return override
        default = select_default_option(options)
        return default.label if default is not None else None

    def _set_platform_bios_aggregates(self, plat: dict[str, Any], slug: str) -> None:
        """Stamp the per-platform BIOS aggregates onto a ``get_firmware_status`` entry.

        Adds ``server_count`` / ``local_count`` / ``required_count`` /
        ``required_downloaded`` and the ``bios_level`` state
        (``"unmanaged"`` / ``"ok"`` / ``"partial"`` / ``"missing"``) so the System
        page reads the decision and the display counts straight off this payload
        instead of re-deriving the threshold logic in the frontend. The
        classification comes from the already-core-aware enriched files, so the
        level matches the per-game game-detail path. Required-file counts key off
        ``classification == "required"`` (the enriched per-core required flag);
        ``known_count`` (registry-recognised files) drives the ``"unmanaged"``
        state when a platform has server files but none map to a registry entry.
        """
        files = plat["files"]
        server_count = len(files)
        local_count = sum(1 for f in files if f["downloaded"])
        required_files = [f for f in files if f["classification"] == "required"]
        required_count = len(required_files)
        required_downloaded = sum(1 for f in required_files if f["downloaded"])
        known_count = sum(1 for f in files if f["classification"] != "unknown")

        bios_obj = format_bios_status(
            {
                "server_count": server_count,
                "local_count": local_count,
                "all_downloaded": local_count >= server_count,
                "required_count": required_count,
                "required_downloaded": required_downloaded,
                "known_count": known_count,
            },
            slug,
        )
        plat["server_count"] = server_count
        plat["local_count"] = local_count
        plat["required_count"] = required_count
        plat["required_downloaded"] = required_downloaded
        plat["bios_level"] = compute_bios_level(bios_obj)

    async def get_firmware_status(self):
        """Return BIOS/firmware status for all platforms on the RomM server.

        When the server is unreachable, falls back to registry-based status
        for installed platforms so core switching remains available offline.
        """
        server_offline = False
        try:
            firmware_list = await self._loop.run_in_executor(None, self._get_firmware_list)
            platforms_map = self._group_server_firmware(firmware_list)
        except Exception as e:
            self._logger.warning(f"Failed to fetch firmware from server: {e}")
            server_offline = True
            platforms_map = self._group_registry_firmware()

        synced_slugs = await self._loop.run_in_executor(None, self._read_synced_slugs)
        self._enrich_platform_map(platforms_map, synced_slugs)
        platforms = sorted(platforms_map.values(), key=lambda p: p["platform_slug"])
        return {"success": True, "server_offline": server_offline, "platforms": platforms}

    def _download_firmware_post_io(self, fw, firmware_id, dest, tmp_path):
        """Sync worker for download_firmware — file rename, hash verification, DB persist.

        Runs in an executor. The filesystem work (rename, checksum) happens
        outside any transaction; only the ``BiosFile`` upsert is wrapped in a
        short write UoW (ADR-0006).

        Returns ``(md5_match, registry_hash_valid, error)``. ``error`` is a
        string when the firmware is malformed — RomM data that fails the
        ``BiosFile`` invariants (empty slug/file_name) — in which case the
        renamed file is removed and nothing is persisted; otherwise ``None``.
        """
        file_name = fw.get("file_name", "")
        self._firmware_file_store.rename(tmp_path, dest)

        # Compute local MD5 once (used for both server-hash and registry-hash checks)
        expected_md5 = fw.get("md5_hash", "")
        reg_entry = self._resolve_index_entry(file_name, expected_md5)
        reg_md5 = reg_entry.get("md5", "") if reg_entry else ""

        local_md5 = self._firmware_file_store.checksum_md5(dest) if (expected_md5 or reg_md5) else None

        md5_match = local_md5 == expected_md5 if expected_md5 and local_md5 is not None else None
        registry_hash_valid = local_md5.lower() == reg_md5.lower() if reg_md5 and local_md5 is not None else None

        try:
            bios_file = BiosFile.mark_downloaded(
                platform_slug=firmware_paths.parse_firmware_slug(fw.get("file_path", "")),
                file_name=file_name,
                file_path=dest,
                downloaded_at=self._clock.now().isoformat(),
                firmware_id=firmware_id,
            )
        except ValueError as e:
            # Malformed RomM firmware (e.g. file_path with no parseable slug):
            # the aggregate's invariant rejects it. Drop the renamed file so we
            # don't leave it untracked, and signal a download failure.
            self._firmware_file_store.remove_file(dest)
            return md5_match, registry_hash_valid, f"Invalid firmware metadata: {e}"

        with self._uow_factory() as uow:
            uow.bios_files.save(bios_file)

        return md5_match, registry_hash_valid, None

    async def download_firmware(self, firmware_id):
        """Download a single firmware file from RomM."""
        firmware_id = int(firmware_id)
        try:
            fw = await self._loop.run_in_executor(None, self._romm_api.get_firmware, firmware_id)
        except Exception as e:
            self._logger.error(f"Failed to fetch firmware {firmware_id}: {e}")
            return error_response(e)

        file_name = fw.get("file_name", "")
        try:
            dest = self._firmware_dest_path(fw)
        except PathTraversalError as e:
            self._logger.error(f"Rejected firmware with unsafe file name {file_name!r}: {e}")
            return {
                "success": False,
                "reason": "path_traversal",
                "message": "Server sent an unsafe firmware file name — download aborted",
            }
        tmp_path = dest + ".tmp"

        try:
            await self._loop.run_in_executor(None, self._firmware_file_store.make_dirs, os.path.dirname(dest))
            await self._loop.run_in_executor(None, self._romm_api.download_firmware, firmware_id, file_name, tmp_path)
        except Exception as e:
            await self._loop.run_in_executor(None, self._firmware_file_store.remove_file, tmp_path)
            self._logger.error(f"Failed to download firmware {file_name}: {e}")
            return error_response(e)

        md5_match, registry_hash_valid, post_io_error = await self._loop.run_in_executor(
            None, self._download_firmware_post_io, fw, firmware_id, dest, tmp_path
        )
        if post_io_error is not None:
            self._logger.error(f"Failed to persist firmware {file_name}: {post_io_error}")
            return error_response(ValueError(post_io_error))

        self.invalidate_firmware_cache()
        self._logger.info(f"Firmware downloaded: {file_name} -> {dest}")
        return {"success": True, "file_path": dest, "md5_match": md5_match, "registry_hash_valid": registry_hash_valid}

    async def download_all_firmware(self, platform_slug):
        """Download all firmware for a given platform slug."""
        try:
            firmware_list = await self._loop.run_in_executor(None, self._get_firmware_list)
        except Exception as e:
            self._logger.error(f"Failed to fetch firmware: {e}")
            resp = error_response(e)
            resp["downloaded"] = 0
            return resp

        # Filter by platform slug (use mapped slugs, e.g. "psx" -> ["psx", "ps"])
        fw_slugs = firmware_paths.resolve_firmware_slugs(platform_slug)
        platform_firmware = []
        for fw in firmware_list:
            slug = firmware_paths.parse_firmware_slug(fw.get("file_path", ""))
            if slug in fw_slugs:
                platform_firmware.append(fw)

        downloaded = 0
        errors = []
        for fw in platform_firmware:
            dest = self._safe_firmware_dest_path(fw)
            if dest is not None and self._firmware_file_store.exists(dest):
                continue
            result = await self.download_firmware(fw["id"])
            if result.get("success"):
                downloaded += 1
            else:
                errors.append(fw.get("file_name", str(fw["id"])))

        msg = f"Downloaded {downloaded} firmware files"
        if errors:
            msg += f" ({len(errors)} failed: {', '.join(errors)})"
        return {"success": True, "message": msg, "downloaded": downloaded}

    def _is_firmware_required(self, file_name, core_so, md5=""):
        """Check if a firmware file is required for the given core."""
        index_entry = self._resolve_index_entry(file_name, md5)
        if not index_entry:
            return None  # Unknown file
        if core_so and "cores" in index_entry and core_so in index_entry["cores"]:
            return index_entry["cores"][core_so]["required"]
        return index_entry.get("required", True)

    async def _download_firmware_batch(self, platform_firmware):
        """Download a batch of firmware files, skipping already-downloaded ones."""
        downloaded = 0
        errors = []
        for fw in platform_firmware:
            dest = self._safe_firmware_dest_path(fw)
            if dest is not None and self._firmware_file_store.exists(dest):
                continue
            result = await self.download_firmware(fw["id"])
            if result.get("success"):
                downloaded += 1
            else:
                errors.append(fw.get("file_name", str(fw["id"])))
        return downloaded, errors

    async def download_required_firmware(self, platform_slug):
        """Download only required firmware for a given platform slug."""
        try:
            firmware_list = await self._loop.run_in_executor(None, self._get_firmware_list)
        except Exception as e:
            self._logger.error(f"Failed to fetch firmware: {e}")
            resp = error_response(e)
            resp["downloaded"] = 0
            return resp

        system = self._resolve_system(platform_slug)
        fw_slugs = firmware_paths.resolve_firmware_slugs(platform_slug)
        core_so, _ = self._core_info.get_active_core(system)

        platform_firmware = [
            fw
            for fw in firmware_list
            if firmware_paths.parse_firmware_slug(fw.get("file_path", "")) in fw_slugs
            and self._is_firmware_required(fw.get("file_name", ""), core_so, fw.get("md5_hash", "")) is True
        ]

        downloaded, errors = await self._download_firmware_batch(platform_firmware)

        msg = f"Downloaded {downloaded} required firmware files"
        if errors:
            msg += f" ({len(errors)} failed: {', '.join(errors)})"
        return {"success": True, "message": msg, "downloaded": downloaded}

    async def check_platform_bios(self, platform_slug, active_core_so=None):
        """Check if RomM has firmware for this platform and whether it's downloaded.

        Returns BIOS status only. ``active_core_so`` is the pre-resolved core used
        to filter the firmware list by what THIS core needs (an INPUT to
        ``collect_firmware_status`` so ``required_count`` / the missing-BIOS badge
        stay core-aware); it is never served back to the UI. ``None`` means "use
        the system default" (resolved here via ``get_active_core(system)``); the
        per-game game-detail path passes the ROM's resolved ``.so``. Core info
        reaches the frontend through the dedicated ``get_platform_core_info``
        path, not this payload (#923).

        A failed firmware fetch degrades to the local registry, which still
        answers the requirement for a covered platform. An uncovered platform has
        nothing to degrade to, so the ``needs_bios: False`` that comes back then
        carries ``bios_status_unknown: True`` — no consumer may read that one as
        "this platform needs none" (#1693).
        """
        system = self._resolve_system(platform_slug)
        fw_slugs = firmware_paths.resolve_firmware_slugs(platform_slug)
        active_core_so = self._resolve_bios_filter_core(system, active_core_so)

        # Build combined registry entries for this platform from all mapped slugs
        registry_platform = {}
        for slug in fw_slugs:
            registry_platform.update(self._bios_registry.get("platforms", {}).get(slug, {}))

        try:
            firmware_list = await self._loop.run_in_executor(None, self._get_firmware_list)
            items = self._build_firmware_status_items(
                fw for fw in firmware_list if firmware_paths.parse_firmware_slug(fw.get("file_path", "")) in fw_slugs
            )
            files = collect_firmware_status(items, registry_platform, active_core_so)
        except Exception:
            if not registry_platform:
                # Nothing left to answer from: the server list is the only source
                # of the requirement for a platform the registry does not cover,
                # so this is "we don't know", not "needs none" (#1693). Reporting
                # it as a negative would clear the "unmanaged" state a successful
                # check had shown.
                return {
                    "needs_bios": False,
                    "bios_status_unknown": True,
                }
            registry_items = []
            for file_name, reg_entry in registry_platform.items():
                dest = self._safe_registry_dest_path(reg_entry.get("firmware_path", file_name))
                if dest is None:
                    continue
                registry_items.append(
                    {
                        "file_name": file_name,
                        "downloaded": self._firmware_file_store.exists(dest),
                        "dest": dest,
                    }
                )
            files = collect_firmware_status(registry_items, registry_platform, active_core_so)

        if not files:
            return {
                "needs_bios": False,
            }

        server_count = len(files)
        local_count = sum(1 for f in files if f.downloaded)

        # required_count/required_downloaded: only files used by the active core (for badge)
        active_files = [f for f in files if f.used_by_active]
        required_files = [f for f in active_files if f.classification == "required"]

        result = {
            "needs_bios": True,
            "server_count": server_count,
            "local_count": local_count,
            "all_downloaded": local_count >= server_count,
            "required_count": len(required_files),
            "required_downloaded": sum(1 for f in required_files if f.downloaded),
            "unknown_count": sum(1 for f in files if f.classification == "unknown"),
            "known_count": sum(1 for f in files if f.classification != "unknown"),
            "files": [asdict(f) for f in files],
        }
        # bios_level state ("unmanaged" / "ok" / "partial" / "missing") so the
        # frontend reads the classification straight off this payload instead of
        # re-deriving the threshold logic. "unmanaged" (server files present, none
        # registry-known) replaces the false "ok" for platforms with no coverage.
        # Matches the System page and per-game game-detail paths.
        result["bios_level"] = compute_bios_level(format_bios_status(result, platform_slug))
        return result

    def _delete_platform_bios_io(self, platform_slug, files):
        """Sync worker for delete_platform_bios — file deletions then DB prune.

        Runs in an executor. Every filesystem removal happens outside any
        transaction; only the ``BiosFile`` deletes for the files that were
        actually removed are wrapped in a single short write UoW (ADR-0006).
        """
        deleted = 0
        errors = []
        removed_names: list[str] = []
        for f in files:
            if not f["downloaded"]:
                continue
            try:
                self._firmware_file_store.remove_file(f["local_path"])
            except OSError as e:
                self._logger.warning(f"Failed to remove BIOS file {f['file_name']}: {e}")
                errors.append(f"{f['file_name']}: {e}")
                continue
            deleted += 1
            removed_names.append(f["file_name"])

        if removed_names:
            self._prune_bios_records(platform_slug, removed_names)

        return deleted, errors

    def _prune_bios_records(self, platform_slug, file_names):
        """Delete the ``BiosFile`` records for *file_names* on *platform_slug*.

        The BIOS rows are keyed by the firmware-directory slug stored at download
        time, which may differ from the platform slug (e.g. ``psx`` → ``ps``), so
        we resolve the candidate firmware slugs and match each removed filename
        against the records under them. One short write UoW.
        """
        fw_slugs = firmware_paths.resolve_firmware_slugs(platform_slug)
        wanted = set(file_names)
        with self._uow_factory() as uow:
            keys = [
                (record.platform_slug, record.file_name)
                for slug in fw_slugs
                for record in uow.bios_files.iter_by_platform(slug)
                if record.file_name in wanted
            ]
            for slug, file_name in keys:
                uow.bios_files.delete(slug, file_name)

    async def delete_platform_bios(self, platform_slug):
        """Delete locally downloaded BIOS files for a platform."""
        bios_status = await self.check_platform_bios(platform_slug)
        if not bios_status.get("needs_bios") or not bios_status.get("files"):
            return {"success": True, "deleted_count": 0, "message": "No BIOS files for this platform"}

        deleted, errors = await self._loop.run_in_executor(
            None, self._delete_platform_bios_io, platform_slug, bios_status["files"]
        )
        self.invalidate_firmware_cache()

        if errors:
            return {
                "success": False,
                "reason": ErrorCode.UNKNOWN.value,
                "deleted_count": deleted,
                "message": f"Deleted {deleted} file(s), {len(errors)} error(s)",
            }
        return {"success": True, "deleted_count": deleted, "message": f"Deleted {deleted} BIOS file(s)"}

    async def check_xemu_alignment(self) -> dict[str, Any]:
        """Check whether xemu's own configuration points at this plugin's BIOS directory.

        Discriminated-status union (Callable response shapes carve-out):
        ``status`` is ``"ok"`` when xemu.toml's ``bootrom_path`` and
        ``flashrom_path`` both resolve to this plugin's BIOS directory,
        ``"misaligned"`` when xemu.toml was read but either does not,
        ``"not_found"`` when no xemu.toml exists at any known location (xemu
        likely hasn't been launched yet), or ``"unreadable"`` when one was
        found but could not be read or parsed. ``hdd_path`` is reported in
        ``files`` for information only and never drives ``status`` — where
        EmuDeck places the Xbox disk image is not confirmed the way the BIOS
        directory is, so a mismatch there is not treated as an error (see
        docs/user-guide/bios-management.md#xbox-xemu).
        """
        sys_files, config_path = await self._loop.run_in_executor(None, self._xemu_config.get_sys_files)
        if config_path is None:
            return {"status": "not_found", "config_path": None, "files": {}}
        if sys_files is None:
            return {"status": "unreadable", "config_path": config_path, "files": {}}

        files = compute_xemu_alignment(sys_files, self._launcher_paths.bios_path())
        aligned = files["bootrom_path"]["in_plugin_bios_dir"] and files["flashrom_path"]["in_plugin_bios_dir"]
        return {
            "status": "ok" if aligned else "misaligned",
            "config_path": config_path,
            "files": files,
        }
