"""Save version history reads and rollback orchestration.

Coordinates the rollback flow (pre-flight sync, version pick, atomic
switch) but does not perform the actual file or server writes — those
go through SyncEngine / LocalSavesAdapter. Anything that lists,
fetches, or rolls back to an older save version lives here. Mutations
of the active save record outside the rollback flow (conflict
resolution, status reporting) belong in SyncEngine or StatusService.
Persistence is the operation's own narrow Unit of Work (ADR-0006).
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from domain.iso_time import parse_iso_to_epoch
from domain.rom_save_sync_state import RomSaveSyncState
from domain.save_layout import SAVE_SYNC_CONTENT_DIR_REASON
from domain.save_slot import save_in_slot, slot_query_param
from domain.save_status import compute_multi_file_slot
from lib.errors import RommNotFoundError
from services.saves._helpers import save_target
from services.saves._settings import resolve_default_slot

if TYPE_CHECKING:
    import asyncio
    import logging
    from collections.abc import Callable

    from services.protocols import DebugLogger, RetryStrategy, RommSaveApi, UnitOfWorkFactory
    from services.saves.rom_info import RomInfoService
    from services.saves.sync_engine import SyncEngine
    from services.saves.sync_engine.devices import DeviceRegistry


@dataclass(frozen=True)
class VersionsServiceConfig:
    """Frozen wiring bundle handed to ``VersionsService.__init__``.

    Holds the live ``settings.json`` dict (default-slot seeding), the
    Unit-of-Work factory (the transactional seam over the SQLite
    repositories), the peer save sub-services consumed during rollback
    orchestration (sync_engine, rom_info, and the shared
    :class:`DeviceRegistry` that owns the server device id), the core
    resolver used to stamp the upload emulator tag, the Protocol-typed
    RomM adapter and retry strategy, the plugin event loop, the
    standard-library logger, and the ``DebugLogger`` seam.
    """

    settings: dict[str, Any]
    uow_factory: UnitOfWorkFactory
    sync_engine: SyncEngine
    device_registry: DeviceRegistry
    rom_info: RomInfoService
    resolve_core: Callable[[int], str | None]
    romm_api: RommSaveApi
    retry: RetryStrategy
    loop: asyncio.AbstractEventLoop
    logger: logging.Logger
    log_debug: DebugLogger


class VersionsService:
    """Aggregate root for the module's contract.

    Per-ROM lock acquisition is delegated to the injected ``SyncEngine``;
    save-state persistence is the operation's own narrow Unit of Work. This
    class owns the rollback orchestration on top of them.
    """

    def __init__(self, *, config: VersionsServiceConfig) -> None:
        self._config = config
        self._settings = config.settings
        self._uow_factory = config.uow_factory
        self._sync_engine = config.sync_engine
        self._device_registry = config.device_registry
        self._rom_info = config.rom_info
        self._resolve_core = config.resolve_core
        self._romm_api = config.romm_api
        self._retry = config.retry
        self._loop = config.loop
        self._logger = config.logger
        self._log_debug = config.log_debug

    # ------------------------------------------------------------------
    # Narrow-UoW read/write helpers (ADR-0006)
    # ------------------------------------------------------------------

    def _read_inputs(self, rom_id: int) -> tuple[RomSaveSyncState, str | None]:
        with self._uow_factory() as uow:
            state = uow.rom_save_sync_states.get(rom_id) or RomSaveSyncState()
        return state, self._device_registry.get_device_id()

    def _write_save_state(self, rom_id: int, save_state: RomSaveSyncState) -> None:
        with self._uow_factory() as uow:
            uow.rom_save_sync_states.save(rom_id, save_state)

    def _local_component_filenames(self, rom_id: int) -> list[str]:
        """Distinct local save filenames on disk for the ROM (one per extension).

        Used to detect a multi-file save — more than one distinct filename
        means the slot's current save is an N-file set (e.g. Saturn
        ``.bkr``/``.bcr``/``.smpc``), not a single file with a version
        history (#908 interim guard). Reads only the local saves directory,
        no network: a rollback target is always an *installed* ROM, so its
        component files are present on disk. Returns an empty list when the
        ROM is not installed.
        """
        return [lf["filename"] for lf in self._rom_info.find_save_files(rom_id)]

    # ------------------------------------------------------------------
    # Version History API
    # ------------------------------------------------------------------

    async def list_file_versions(self, rom_id: int, slot: str, filename: str) -> dict[str, Any]:
        """List server-side saves in the active slot, excluding the currently-tracked one.

        The slot is the unit, not the filename. Saves uploaded by other
        clients (RomM web UI, third-party clients, etc.) whose naming
        convention differs from ours are first-class versions of the same
        slot, so no filename filter is applied — every save in the slot
        except the one we're currently tracking shows up here.

        ``filename`` is kept in the signature for compatibility with the
        callable wiring but no longer affects which versions are returned.

        Returns a status dict:
        - ``{"status": "ok", "versions": [...]}`` on success. ``versions``
          is sorted by ``updated_at`` descending (newest first); each entry
          contains: id, file_name, emulator, updated_at, file_size_bytes,
          device_syncs, uploaded_by_us. ``versions`` may be empty — the
          server answered, nothing matched.
        - ``{"status": "multi_file_unsupported", "versions": []}`` when the
          slot's current save spans more than one distinct file (e.g.
          Saturn ``.bkr``/``.bcr``/``.smpc``). The sibling records are
          components of one game state, not prior versions, so listing them
          as history would be misleading and rolling back would corrupt the
          set. Interim #908 guard — the frontend already hides the panel via
          ``get_save_status``'s ``multi_file`` flag; this is the defensive
          backstop for any direct caller.
        - ``{"status": "server_unreachable", "message": ...}`` if the
          ``list_saves`` call failed (network, server, auth, etc.). The
          frontend distinguishes this from an empty list so it can show a
          retry affordance instead of "no versions available".
        - ``{"status": "not_found", "message": ...}`` if the ``list_saves``
          call drew a definitive 404 — RomM no longer has this ROM or the
          registered device id. Distinct from ``server_unreachable``: the
          server answered, so retrying is pointless and the panel says so
          instead of blaming the connection (#1570).
        """
        rom_id = int(rom_id)
        save_state, device_id = await self._loop.run_in_executor(None, self._read_inputs, rom_id)

        component_files = await self._loop.run_in_executor(None, self._local_component_filenames, rom_id)
        if compute_multi_file_slot(component_files).is_multi_file:
            self._log_debug(f"list_file_versions: multi-file slot for rom {rom_id} ({component_files}); suppressing")
            return {"status": "multi_file_unsupported", "versions": []}

        try:
            server_saves = await self._loop.run_in_executor(
                None,
                lambda: self._retry.with_retry(
                    lambda: self._romm_api.list_saves(rom_id, device_id=device_id, slot=slot_query_param(slot))
                ),
            )
        except RommNotFoundError as e:
            # The server answered: it has no such ROM (or no such device id). A
            # retry cannot change that, so the panel must not offer one (#1570).
            self._log_debug(f"list_file_versions: server has no such entity: {e}")
            return {"status": "not_found", "message": str(e)}
        except Exception as e:
            self._log_debug(f"list_file_versions: failed to list saves: {e}")
            return {"status": "server_unreachable", "message": str(e)}

        file_state = save_state.files.get(filename)
        tracked_id = file_state.tracked_save_id if file_state else None
        own_upload_ids: list[int] | None = save_state.own_upload_ids

        versions = [
            {
                "id": s["id"],
                "file_name": s.get("file_name", ""),
                "emulator": s.get("emulator"),
                "updated_at": s.get("updated_at", ""),
                "file_size_bytes": s.get("file_size_bytes"),
                "device_syncs": s.get("device_syncs", []),
                "uploaded_by_us": (s["id"] in own_upload_ids) if own_upload_ids is not None else None,
            }
            for s in server_saves
            if s.get("id") != tracked_id and save_in_slot(s, slot)
        ]

        versions.sort(key=lambda v: parse_iso_to_epoch(v["updated_at"]) or 0.0, reverse=True)
        return {"status": "ok", "versions": versions}

    def _rollback_to_version_io(
        self,
        rom_id: int,
        save_state: RomSaveSyncState,
        device_id: str | None,
        core_so: str | None,
        save_id: int,
        info: dict[str, Any],
        server_saves: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Blocking I/O portion of the version-switch flow — runs in executor.

        The caller is responsible for the matrix pre-flight: by the time
        this function runs, the currently-tracked save is already in sync
        with the server (or the switch was aborted before we got here).
        This function is purely the destructive switch:

        1. Download id=save_id content → overwrite local file.
           ``do_download_save`` updates ``tracked_save_id`` /
           ``last_sync_hash`` to point at the target version locally.
        2. PUT id=save_id with the same content. RomM bumps
           ``save.updated_at`` to NOW (the ``onupdate=utc_now`` hook) and
           upserts our DeviceSaveSync row (``synced_at = updated_at``), so
           id=save_id is now newest in the slot and ``is_current`` already
           evaluates true for us.
        3. ``do_upload_save`` acks via ``_confirm_upload_sync``. The PUT
           already upserted our sync row (RomM's PUT auto-upserts on every
           supported version), so this ack is at most a redundant idempotent
           re-write, not the required step it was once described as (#1458).
        4. ``do_upload_save`` refreshes local sync state via
           ``update_file_sync_state`` to match the post-PUT response.

        After this, the next ``compute_sync_action`` run picks id=save_id
        (now newest), our ``is_current=true``, hash matches →
        ``Skip(synced)``. Other devices on their next sync see id=save_id
        as newest with their ``is_current=false`` → ``Download`` → adopt
        our switch. Cross-device propagation works. Mutates *save_state* in
        memory; the caller owns the write UoW.
        """
        target_save = next(
            (s for s in server_saves if s.get("id") == save_id),
            None,
        )
        if target_save is None:
            return {"status": "version_deleted"}

        saves_dir = info["saves_dir"]
        system = info["system"]
        default_slot = resolve_default_slot(self._settings)
        target_filename = save_target(target_save, info, save_state.files)
        if target_filename is None:
            return {"status": "unsupported"}
        local_path = os.path.join(saves_dir, target_filename)

        self._sync_engine.do_download_save(
            target_save,
            saves_dir,
            target_filename,
            save_state,
            device_id,
            system,
            default_slot,
            save_set=info.get("save_set"),
        )

        try:
            self._sync_engine.do_upload_save(
                rom_id,
                local_path,
                target_filename,
                save_state,
                device_id,
                system,
                core_so,
                target_save,
                default_slot,
            )
        except Exception as e:
            # Download already mutated local state to reflect ``save_id``, so
            # the switch is locally complete — but cross-device propagation
            # failed because ``updated_at`` was not bumped. Surface this so
            # the caller can prompt the user to retry.
            self._logger.error(
                "_rollback_to_version_io: PUT to bump updated_at failed for rom=%s save=%s: %s",
                rom_id,
                save_id,
                e,
            )
            return {"status": "put_failed", "message": str(e)}

        return {"status": "ok"}

    async def rollback_to_version(self, rom_id: int, slot: str, save_id: int) -> dict[str, Any]:
        """Switch the local + tracked save to a chosen older server version.

        Flow:

        1. Run ``do_sync_rom_saves`` as a matrix pre-flight on the
           currently-tracked save. The matrix decides:

           - ``Skip(synced)`` / ``Skip(adopt_baseline=True)`` — proceed.
           - ``Upload(POST/PUT)`` — silently push local up, then proceed.
           - ``Download(server)`` — silently adopt the server-newest, then
             proceed (the user's chosen target is still in the slot).
           - ``Conflict`` — abort with ``conflict_blocked``; user must
             resolve via the standard ``SyncConflictModal`` first.

        2. After a clean pre-flight, the destructive switch runs in
           ``_rollback_to_version_io``: download chosen → write to
           canonical local target → PUT same content → ``confirm_download``.

        ``filename`` is kept in the signature for callable-wiring stability
        but no longer drives any decision — the canonical local path is
        derived from the target save and the ROM name.

        Returns a status dict:
        - ``{"status": "ok"}`` on success.
        - ``{"status": "rom_not_installed"}`` if the ROM is not installed
          locally. The frontend distinguishes this from
          ``version_deleted`` so it can prompt the user to reinstall the
          ROM rather than telling them the version is gone from the
          server.
        - ``{"status": "unsupported"}`` if the slot's current save spans
          more than one distinct file (e.g. Saturn ``.bkr``/``.bcr``/
          ``.smpc``). Per-version rollback would revert one component and
          leave the others — an incoherent save — so it is refused.
          Interim #908 guard; grouped atomic-set rollback is tracked there.
          It is also returned, without a reason, when the chosen save is
          not a file of the ROM's save set under its current emulator (a
          standalone emulator's set never takes another emulator's save).
          The same status carries an additive
          ``"reason": "savefiles_in_content_dir"`` field when the refusal is
          instead because RetroArch writes saves to the content dir (#239):
          the rollback's ``saves_dir`` target is ignored by RetroArch, so the
          switch could never take effect. The frontend already hides the panel
          via ``get_save_status``'s ``rollback_supported=False``; the
          additive reason lets a direct caller distinguish the two causes.
        - ``{"status": "version_deleted"}`` if the chosen save id is no
          longer on the server (genuinely deleted — the ``list_saves``
          call succeeded and the id was absent).
        - ``{"status": "server_unreachable", "message": ...}`` if the
          post-preflight ``list_saves`` call failed (network, server,
          auth, etc.). The frontend distinguishes this from
          ``version_deleted`` so it can show a retry affordance instead
          of "version no longer on the server".
        - ``{"status": "not_found", "message": ...}`` if that same call drew
          a definitive 404 — RomM no longer has this ROM or the registered
          device id. Distinct from both siblings: ``version_deleted`` is one
          missing save inside a ROM the server still has, and
          ``server_unreachable`` is a connection the user can retry (#1570).
        - ``{"status": "conflict_blocked", "conflicts": [...]}`` if the
          pre-flight surfaced a conflict on the currently-tracked save.
          The frontend resolves it via the standard conflict modal.
        - ``{"status": "preflight_failed", "errors": [...]}`` if the
          pre-flight hit non-conflict errors (network, server, etc.).
          No switch was attempted.
        - ``{"status": "put_failed", "message": ...}`` if the local
          download succeeded but the server-side ``updated_at`` bump
          failed. Local file and state already point at the target;
          retrying is safe and idempotent. Without a successful re-PUT
          the switch will not propagate cross-device.
        """
        rom_id = int(rom_id)
        save_id = int(save_id)

        async with self._sync_engine.rom_lock(rom_id):
            info = self._rom_info.get_rom_save_info(rom_id)
            if not info:
                return {"status": "rom_not_installed"}

            # Interim #908 guard: refuse per-version rollback on a multi-file
            # slot (e.g. Saturn .bkr/.bcr/.smpc) before any destructive or
            # preflight I/O runs — rolling one component back would leave the
            # others, producing an incoherent save. Local-only (no network):
            # a rollback target is always installed, so its component files
            # are on disk.
            component_files = await self._loop.run_in_executor(None, self._local_component_filenames, rom_id)
            if compute_multi_file_slot(component_files).is_multi_file:
                self._log_debug(f"rollback_to_version: multi-file slot for rom {rom_id} ({component_files}); refusing")
                return {"status": "unsupported"}

            # #239: RetroArch writes saves to the content dir — the rollback's
            # download/PUT target is ``saves_dir``, which RetroArch ignores, so
            # the switch could not take effect. Refuse before any preflight or
            # destructive I/O. Reuse the existing ``unsupported`` status (the
            # frontend already routes it to a benign refusal toast) and add the
            # ``reason`` slug so a direct caller can distinguish the cause.
            if await self._sync_engine.content_dir_blocked("rollback_to_version"):
                self._log_debug(f"rollback_to_version: content-dir layout for rom {rom_id}; refusing")
                return {"status": "unsupported", "reason": SAVE_SYNC_CONTENT_DIR_REASON}

            save_state, device_id = await self._loop.run_in_executor(None, self._read_inputs, rom_id)
            core_so = await self._loop.run_in_executor(None, self._resolve_core, rom_id)
            default_slot = resolve_default_slot(self._settings)

            # Matrix pre-flight: get the tracked save in sync first, or surface
            # a conflict that the user must resolve before any switch can run.
            _uploaded, _downloaded, errors, conflicts = await self._loop.run_in_executor(
                None, self._sync_engine.do_sync_rom_saves, rom_id, save_state, device_id, core_so, default_slot
            )
            if conflicts:
                await self._loop.run_in_executor(None, self._write_save_state, rom_id, save_state)
                return {
                    "status": "conflict_blocked",
                    "conflicts": list(conflicts),
                }
            if errors:
                await self._loop.run_in_executor(None, self._write_save_state, rom_id, save_state)
                return {"status": "preflight_failed", "errors": errors}

            # Re-fetch server saves after the pre-flight: it may have created
            # or modified saves the switch needs to see.
            try:
                server_saves: list[dict[str, Any]] = await self._loop.run_in_executor(
                    None,
                    lambda: self._retry.with_retry(
                        lambda: self._romm_api.list_saves(rom_id, device_id=device_id, slot=slot_query_param(slot))
                    ),
                )
            except RommNotFoundError as e:
                # The server answered: it has no such ROM (or no such device id).
                # Not a connectivity verdict, so the toast must not blame the
                # connection or invite a retry that cannot succeed (#1570).
                self._log_debug(f"rollback_to_version: server has no such entity: {e}")
                await self._loop.run_in_executor(None, self._write_save_state, rom_id, save_state)
                return {"status": "not_found", "message": str(e)}
            except Exception as e:
                self._log_debug(f"rollback_to_version: failed to list saves: {e}")
                # Persist whatever the pre-flight mutated before bailing.
                await self._loop.run_in_executor(None, self._write_save_state, rom_id, save_state)
                return {"status": "server_unreachable", "message": str(e)}

            # Scope to the requested slot. Legacy ('' / None) omitted the param
            # and got every save, so filter to slot:null here too (#1061); a
            # save_id from another slot then resolves to version_deleted in
            # _rollback_to_version_io rather than rolling back cross-slot.
            server_saves = [s for s in server_saves if save_in_slot(s, slot)]

            try:
                result = await self._loop.run_in_executor(
                    None,
                    self._rollback_to_version_io,
                    rom_id,
                    save_state,
                    device_id,
                    core_so,
                    save_id,
                    info,
                    server_saves,
                )
            finally:
                # The pre-flight ``do_sync_rom_saves`` already performed real
                # uploads/downloads whose baselines/tracked-ids live only in the
                # in-memory aggregate; persist them regardless of how the switch
                # ends, or the next sync mis-classifies (#1012).
                await self._loop.run_in_executor(None, self._write_save_state, rom_id, save_state)

            return result
