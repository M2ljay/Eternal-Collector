"""Slot listing reads against the live server + persisted state.

Anything that reads slot inventory for the QAM (merging persisted local
slots with the server view and projecting the result back to SQLite)
lives here. Mutating writes for the active slot, the setup wizard, and
slot deletion belong in their own sub-modules.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from domain.rom_save_sync_state import RomSaveSyncState
from domain.save_slot import save_in_slot, slot_query_param
from lib.errors import classify_error
from services.saves._messages import SAVE_SYNC_DISABLED
from services.saves._settings import resolve_default_slot, save_sync_enabled

if TYPE_CHECKING:
    import asyncio

    from services.protocols import (
        DebugLogger,
        RetryStrategy,
        RommSaveApi,
        UnitOfWorkFactory,
    )
    from services.saves.sync_engine.devices import DeviceRegistry


class SlotListing:
    """Slot inventory reader: merges server slot summaries with persisted local slots."""

    def __init__(
        self,
        *,
        settings: dict[str, Any],
        uow_factory: UnitOfWorkFactory,
        device_registry: DeviceRegistry,
        romm_api: RommSaveApi,
        retry: RetryStrategy,
        loop: asyncio.AbstractEventLoop,
        log_debug: DebugLogger,
    ) -> None:
        self._settings = settings
        self._uow_factory = uow_factory
        self._device_registry = device_registry
        self._romm_api = romm_api
        self._retry = retry
        self._loop = loop
        self._log_debug = log_debug

    def _read_inputs(self, rom_id: int) -> tuple[RomSaveSyncState | None, str | None]:
        with self._uow_factory() as uow:
            state = uow.rom_save_sync_states.get(rom_id)
        return state, self._device_registry.get_device_id()

    async def get_save_slots(self, rom_id: int) -> dict[str, Any]:
        """List available save slots for a ROM.

        Merges server slots with locally-created slots. Persists the merged
        result so local slots survive restarts. Promotes local slots to server
        when they appear on the server. Removes server slots that no longer
        exist on the server (unless they are the active_slot).

        A failed server fetch answers no slots — but carries the persisted
        listing in its own ``last_known`` field for a ROM whose active slot the
        user confirmed, so the QAM can show what the last contact left behind
        (:func:`_last_known_snapshot`).
        """
        rom_id = int(rom_id)
        if not save_sync_enabled(self._settings):
            return {
                "success": False,
                "reason": "sync_disabled",
                "message": SAVE_SYNC_DISABLED,
                "slots": [],
                "active_slot": "autosave",
            }

        rom_state, device_id = await self._loop.run_in_executor(None, self._read_inputs, rom_id)
        default_slot = resolve_default_slot(self._settings)
        # ROM not tracked → fall back to the global default slot. ROM
        # tracked with ``active_slot=None`` → preserve legacy mode (None
        # means "no slots"; the persisted slots dict will contain ``""``).
        if rom_state is None:
            active_slot: str | None = default_slot
            persisted_slots: dict[str, dict[str, Any]] = {}
        else:
            active_slot = rom_state.active_slot
            persisted_slots = rom_state.slots

        # Fetch server slots. On failure we MUST NOT persist a merged map —
        # an empty server_slots_list would drop every persisted server slot
        # except the active one and the user would see their slot inventory
        # vanish on a transient network blip.
        try:
            summary = await self._loop.run_in_executor(
                None,
                lambda: self._retry.with_retry(
                    lambda: self._romm_api.get_save_summary(rom_id, device_id=device_id),
                ),
            )
        except Exception as e:
            self._log_debug(f"Failed to fetch save slots for rom {rom_id}: {e}")
            reason, _message = classify_error(e)
            return {
                "success": False,
                "reason": reason,
                # The raw exception text is neutral and carries the concrete
                # detail; only the routing slug was ever wrong here.
                "message": str(e),
                "slots": [],
                "active_slot": active_slot,
                "last_known": _last_known_snapshot(rom_state),
            }
        server_slots_list: list[dict[str, Any]] = summary.get("slots", [])

        # Merge: update persisted slots with server data, promote local→server
        merged: dict[str, dict[str, Any]] = {}
        for s in server_slots_list:
            raw = s.get("slot") or s.get("slot_name")
            name = raw if raw else ""
            merged[name] = {
                "source": "server",
                "count": s.get("count", 0),
                "latest_updated_at": (s.get("latest") or {}).get("updated_at"),
            }

        self._merge_persisted_slots(persisted_slots, merged, active_slot)

        # Persist merged slots in state. The aggregate may not exist yet (ROM
        # never synced) — start a fresh default and seed its active slot.
        if rom_state is None:
            game_entry = RomSaveSyncState()
            game_entry.switch_active_slot(active_slot)
        else:
            game_entry = rom_state
        game_entry.refresh_slot_listing(merged)
        await self._loop.run_in_executor(None, self._write_save_state, rom_id, game_entry)

        return {"success": True, "slots": _slot_rows(merged), "active_slot": active_slot}

    def _write_save_state(self, rom_id: int, save_state: RomSaveSyncState) -> None:
        with self._uow_factory() as uow:
            uow.rom_save_sync_states.save(rom_id, save_state)

    @staticmethod
    def _merge_persisted_slots(
        persisted: dict[str, dict[str, Any]],
        merged: dict[str, dict[str, Any]],
        active_slot: str | None,
    ) -> None:
        """Add persisted local slots (or the active slot) that aren't on the server.

        Mutates ``merged`` in place. Local slots are always kept. A persisted
        server slot that's gone from the server is dropped unless it's the
        active slot — we want to keep the UI functional until the user
        explicitly switches away.
        """
        for name, info in persisted.items():
            if name in merged:
                continue
            if info.get("source") == "local":
                merged[name] = {"source": "local", "count": 0, "latest_updated_at": None}
            elif info.get("source") == "server" and name == (active_slot or ""):
                merged[name] = {"source": "server", "count": 0, "latest_updated_at": None}

    async def get_slot_saves(self, rom_id: int, slot: str) -> dict[str, Any]:
        """Fetch server save files for a specific slot.

        Used by the frontend to show save files when expanding an inactive slot panel.
        Lightweight — no local file scanning or conflict detection.
        """
        rom_id = int(rom_id)
        slot = str(slot).strip() if slot else ""

        if not save_sync_enabled(self._settings):
            return {
                "success": False,
                "reason": "sync_disabled",
                "message": SAVE_SYNC_DISABLED,
                "slot": slot,
                "saves": [],
            }

        device_id = await self._loop.run_in_executor(None, self._device_registry.get_device_id)

        try:
            # Legacy slot ("" → null on the server) can't be addressed by any
            # ``slot=`` value, so omit the param (slot_query_param → None) and
            # filter the result client-side (#1061). Named slots filter
            # server-side and re-filter for safety.
            server_saves: list[dict[str, Any]] = await self._loop.run_in_executor(
                None,
                lambda: self._retry.with_retry(
                    lambda: self._romm_api.list_saves(rom_id, device_id=device_id, slot=slot_query_param(slot)),
                ),
            )
            saves = [
                {
                    "filename": s["file_name"],
                    "id": s["id"],
                    "size": s.get("file_size_bytes"),
                    "updated_at": s.get("updated_at", ""),
                    "emulator": s.get("emulator", ""),
                }
                for s in server_saves
                if save_in_slot(s, slot)
            ]
            return {"success": True, "slot": slot, "saves": saves}
        except Exception as e:
            reason, _message = classify_error(e)
            return {
                "success": False,
                "reason": reason,
                "message": str(e),
                "slot": slot,
                "saves": [],
            }


def _slot_rows(slots: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    """Project a slot map into the response rows, sorted by slot name."""
    return [
        {
            "slot": name,
            "source": info.get("source", "server"),
            "count": info.get("count", 0),
            "latest_updated_at": info.get("latest_updated_at"),
        }
        for name, info in sorted(slots.items())
    ]


def _last_known_snapshot(rom_state: RomSaveSyncState | None) -> dict[str, Any] | None:
    """Project ``rom_state``'s persisted listing into the ``last_known`` payload.

    ``None`` — "the device knows nothing about this ROM's slots", which a
    caller can never mistake for "this ROM has no slots" — unless the active
    slot is confirmed. On an unconfirmed row ``active_slot`` is this service's
    own default fallback rather than anything the server ever said, and handing
    that out would name a slot the user does not have (#1747).

    Carries no timestamp: the counts and times inside are as of whenever the
    last successful listing wrote them, and nothing on the aggregate records
    when that was. ``last_sync_check_at`` is the nearest thing and is not it —
    a sync or a slot switch advances it while the listing stands still — so
    sending it would date the snapshot with an unrelated, usually newer moment.
    """
    if rom_state is None or not rom_state.slot_confirmed or not rom_state.slots:
        return None
    return {
        "slots": _slot_rows(rom_state.slots),
        "active_slot": rom_state.active_slot,
    }
