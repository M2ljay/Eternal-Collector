"""MigrationService — RetroDECK path and save-sort migration orchestration.

Owns the runtime decisions for relocating ROMs, BIOS, and save files
when the RetroDECK home path changes or RetroArch save sorting flips.
All raw filesystem I/O is delegated to the ``MigrationFileStore``
Protocol; conflict resolution, state mutations, and event emission
remain the service's responsibility.
"""

from __future__ import annotations

import asyncio
import json
import sys
import os
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from domain.migration_paths import (
    compute_pending_home_transition,
    match_pending_base,
    pending_homes_from_kv,
    remap_under_current,
    stranded_source_candidates,
)
from domain.save_extensions import get_save_extensions
from domain.save_layout import ContentDir
from domain.save_path import resolve_save_dir

if TYPE_CHECKING:
    import logging
    from collections.abc import Callable, Sequence

    from models.state import SaveSortSettings

    from domain.rom_install import RomInstall
    from domain.save_layout import InSaveDir, SaveLayout
    from services.protocols import (
        ActiveCoreReader,
        CoreNameProviderFn,
        EventEmitter,
        MigrationFileStore,
        RelaunchOptionsReader,
        RetroArchSaveLayoutProvider,
        RetroDeckPaths,
        SettingsPersister,
        UnitOfWorkFactory,
    )

# kv_config keys for the cross-run change-detection markers MigrationService
# diffs (ADR-0003 Bucket 2): the last-seen RetroDECK home and RetroArch
# save-sort observation, each with a ``_previous`` companion that exists only
# while a migration is awaiting user confirmation. ``_HOPS`` holds the JSON
# array of *additional* pending homes (oldest→newest) accumulated when the
# user changes the RetroDECK home again before migrating (#1042); it is absent
# in the common single-hop case and deleted wherever ``_PREVIOUS`` is.
_KV_RETRODECK_HOME = "retrodeck_home_path"
_KV_RETRODECK_HOME_PREVIOUS = "retrodeck_home_path_previous"
_KV_RETRODECK_HOME_HOPS = "retrodeck_home_path_hops"
_KV_SAVE_SORT = "save_sort_settings"
_KV_SAVE_SORT_PREVIOUS = "save_sort_settings_previous"
_KV_WINDOWS_SAVE_SORT_RESEEDED = "windows_save_sort_reseeded"


@dataclass(frozen=True)
class MigrationServiceConfig:
    """Frozen wiring bundle handed to ``MigrationService.__init__``.

    Holds the Protocol-typed migration-file adapter, the live settings
    dict, runtime infrastructure, persistence callbacks, event emitter,
    and the provider callables MigrationService needs at construction
    time. The shared ``active_core`` resolver answers which RetroArch core a
    ROM launches with when re-deriving the save-sort subdirectory name. The
    ``relaunch_options`` seam re-bakes every relocated ROM's full Steam
    ``launch_options`` (active core + selected disc) from its moved path so the
    pick survives the home migration. Relational migration state (ROM installs,
    BIOS records, change markers) is read through the injected ``uow_factory``.
    """

    migration_file_store: MigrationFileStore
    settings: dict[str, Any]
    loop: asyncio.AbstractEventLoop
    logger: logging.Logger
    settings_persister: SettingsPersister
    emit: EventEmitter
    get_bios_files_index: Callable[[], dict[str, dict[str, Any]]]
    retrodeck_paths: RetroDeckPaths
    get_save_layout: RetroArchSaveLayoutProvider
    active_core: ActiveCoreReader
    relaunch_options: RelaunchOptionsReader
    get_core_name: CoreNameProviderFn
    uow_factory: UnitOfWorkFactory


class MigrationService:
    """Handles RetroDECK path change detection and file migration."""

    def __init__(self, *, config: MigrationServiceConfig) -> None:
        self._migration_file_store = config.migration_file_store
        self._settings = config.settings
        self._loop = config.loop
        self._logger = config.logger
        self._settings_persister = config.settings_persister
        self._emit = config.emit
        self._get_bios_files_index = config.get_bios_files_index
        self._retrodeck_paths = config.retrodeck_paths
        self._get_save_layout = config.get_save_layout
        self._active_core = config.active_core
        self._relaunch_options = config.relaunch_options
        self._get_core_name = config.get_core_name
        self._uow_factory = config.uow_factory
        # One-shot guard so the ContentDir "save sync unsupported" warning is
        # logged at most once per process rather than on every save-sort detect
        # pass (which runs at the entry of every sync flow).
        self._content_dir_warned = False
        # Strong refs to in-flight background tasks. ``loop.create_task``
        # alone is not enough — without a strong ref, the loop is free to
        # garbage-collect the task before it completes. ``add_done_callback``
        # prunes finished entries to keep the set bounded.
        self._background_tasks: set[asyncio.Task[Any]] = set()

    def _spawn_background_task(self, coro) -> asyncio.Task[Any]:
        """Schedule ``coro`` on the plugin loop and track the task for shutdown.

        Wraps ``loop.create_task`` so the resulting task is retained in
        ``_background_tasks`` until completion. ``shutdown()`` cancels any
        still-pending entries on plugin unload.
        """
        task = self._loop.create_task(coro)
        self._background_tasks.add(task)
        task.add_done_callback(self._background_tasks.discard)
        return task

    async def shutdown(self) -> None:
        """Cancel any in-flight background tasks and await their completion.

        Called from ``main._unload`` so RetroDECK path-change notification
        coroutines do not leak across the plugin unload boundary. No-op
        when no tasks are pending.
        """
        for task in self._background_tasks:
            task.cancel()
        if self._background_tasks:
            await asyncio.gather(*self._background_tasks, return_exceptions=True)

    def detect_retrodeck_path_change(self) -> None:
        """Check if RetroDECK home path changed since last run.

        Delegates the pending-home set transition to the pure
        ``compute_pending_home_transition`` kernel: a first change records the
        old home as pending; a change chained on top of a still-pending one
        appends to the pending set instead of overwriting it, so files stranded
        under an intermediate home are never lost (#1042). A revert onto the
        sole pending home auto-clears; any other move is a ``changed``
        transition that re-emits ``retrodeck_path_changed`` with the oldest
        pending home as ``old_path`` (so the banner still reads "From: A →
        To: C").
        """
        current_home = self._retrodeck_paths.retrodeck_home()
        if not current_home:
            return
        if not self._migration_file_store.is_dir(current_home):
            self._logger.warning(f"RetroDECK home path does not exist, skipping: {current_home}")
            return

        with self._uow_factory() as uow:
            stored_home = uow.kv_config.get(_KV_RETRODECK_HOME) or ""
            pending = self._read_pending_homes(uow)

        transition = compute_pending_home_transition(stored_home, current_home, pending)
        if transition.kind == "unchanged":
            return
        if transition.kind == "first_run":
            with self._uow_factory() as uow:
                uow.kv_config.set(_KV_RETRODECK_HOME, current_home)
            return

        with self._uow_factory() as uow:
            uow.kv_config.set(_KV_RETRODECK_HOME, current_home)
            self._write_pending_homes(uow, transition.pending)

        payload: dict[str, Any] = {"old_path": transition.emit_old, "new_path": transition.emit_new}
        if transition.emit_cleared:
            self._logger.info(f"RetroDECK home reverted to previous path; clearing migration marker: {current_home}")
            # ``cleared: True`` lets the frontend listener distinguish the
            # auto-clear emit from a genuine path-change emit and dismiss any
            # pending migration UI.
            payload["cleared"] = True
        else:
            self._logger.warning(f"RetroDECK home path changed: {transition.emit_old} -> {transition.emit_new}")
        self._spawn_background_task(self._emit("retrodeck_path_changed", payload))

    @staticmethod
    def _read_pending_homes(uow) -> list[str]:
        """Read the pending-home set (oldest→newest) from kv_config.

        Reassembles ``[previous, *hops]`` from the ``_previous`` marker and the
        ``_hops`` JSON array; returns ``[]`` when no migration is pending.
        """
        return pending_homes_from_kv(
            uow.kv_config.get(_KV_RETRODECK_HOME_PREVIOUS) or "",
            uow.kv_config.get(_KV_RETRODECK_HOME_HOPS),
        )

    @staticmethod
    def _write_pending_homes(uow, pending: Sequence[str]) -> None:
        """Persist the pending-home set, or clear both markers when it is empty.

        The head becomes ``_previous`` (the marker every existing consumer
        reads); the tail becomes the ``_hops`` JSON array, deleted when there
        is only a single pending home so the common case stays byte-identical
        to the pre-#1042 on-disk shape.
        """
        if not pending:
            uow.kv_config.delete(_KV_RETRODECK_HOME_PREVIOUS)
            uow.kv_config.delete(_KV_RETRODECK_HOME_HOPS)
            return
        uow.kv_config.set(_KV_RETRODECK_HOME_PREVIOUS, pending[0])
        hops = list(pending[1:])
        if hops:
            uow.kv_config.set(_KV_RETRODECK_HOME_HOPS, json.dumps(hops))
        else:
            uow.kv_config.delete(_KV_RETRODECK_HOME_HOPS)

    def is_retrodeck_migration_pending(self) -> bool:
        """Return True if a RetroDECK home path migration is pending."""
        with self._uow_factory() as uow:
            return bool(uow.kv_config.get(_KV_RETRODECK_HOME_PREVIOUS))

    def dismiss_retrodeck_migration(self) -> dict[str, Any]:
        """Dismiss the RetroDECK path migration warning without migrating files."""
        with self._uow_factory() as uow:
            self._write_pending_homes(uow, [])
        return {"success": True}

    def _collect_rom_items(self, pending_homes, new_home, installs, relocations):
        """Collect ROM migration items from the installed-ROM records.

        ``installs`` is a pre-snapshotted list of ``RomInstall`` records (the
        caller opens the read UoW). Emits exactly **one** move unit per install
        (never both a file and its enclosing directory): a folder-backed ROM
        (``rom_dir`` set) moves the whole directory as a unit — kind
        ``"rom_dir"`` — so sibling disc/update/DLC files travel with it; a
        single-file ROM (``rom_dir`` is ``None``) moves just the launch file —
        kind ``"rom"``. Each record's stored path is matched by longest prefix
        against every pending home (#1042), so a record left under an older home
        by a change chained before migrating is still collected; records under
        the current home or an unknown prefix are skipped. Each item carries a
        success-hook updater that records the intended relocation into
        *relocations* (keyed by ``rom_id``) when its move/skip succeeds; the
        relocations are applied to ``rom_installs`` in a separate write UoW
        after the file moves complete (ADR-0006).
        """
        items = []
        for install in installs:
            rom_dir = install.rom_dir
            if rom_dir:
                base = match_pending_base(rom_dir, pending_homes)
                if base is None:
                    continue
                # Multi-file ROM: move the whole dedicated directory as a unit.
                # The launch file lives inside it, so its new path follows the
                # directory's new location.
                new_rom_dir = remap_under_current(rom_dir, base, new_home)
                new_file_path = os.path.join(new_rom_dir, os.path.relpath(install.file_path, rom_dir))
                source = self._resolve_move_source(rom_dir, base, pending_homes, new_rom_dir)
                items.append(
                    (
                        os.path.basename(rom_dir),
                        source,
                        new_rom_dir,
                        self._make_rom_relocation_updater(relocations, install.rom_id, new_rom_dir, new_file_path),
                        "rom_dir",
                    )
                )
            else:
                # Single-file ROM: move only the launch file; it owns no folder.
                file_path = install.file_path
                if not file_path:
                    continue
                base = match_pending_base(file_path, pending_homes)
                if base is None:
                    continue
                new_file_path = remap_under_current(file_path, base, new_home)
                source = self._resolve_move_source(file_path, base, pending_homes, new_file_path)
                items.append(
                    (
                        os.path.basename(file_path),
                        source,
                        new_file_path,
                        self._make_rom_relocation_updater(relocations, install.rom_id, None, new_file_path),
                        "rom",
                    )
                )
        return items

    def _resolve_move_source(self, stored_path, base, pending_homes, dest):
        """Return the best on-disk source for a tracked record's move.

        Normally the record's stored path *is* the source. When that path is
        gone AND the destination is not already there, the file may have been
        stranded under another pending home by an interrupted earlier migration
        (#1042) — probe those homes newest-first and return the first hit. When
        nothing is found the stored path is returned unchanged; the move loop
        then records it as a missing record rather than moving anything.
        """
        if self._migration_file_store.exists(stored_path) or self._migration_file_store.exists(dest):
            return stored_path
        rel = os.path.relpath(stored_path, base)
        for candidate in stranded_source_candidates(rel, base, pending_homes):
            if self._migration_file_store.exists(candidate):
                return candidate
        return stored_path

    @staticmethod
    def _make_rom_relocation_updater(relocations, rom_id, new_rom_dir, new_file_path):
        """Build a success-hook closure that records one install's new paths.

        The migration loop calls the returned updater once the move (or skip)
        for this install's single move unit succeeds. It records the new
        ``rom_dir`` (``None`` for a single-file ROM) and ``file_path`` per
        ``rom_id`` into *relocations* so the post-move write UoW can apply
        ``RomInstall.relocate`` for each moved install.
        """

        def update():
            relocations[rom_id] = {"rom_dir": new_rom_dir, "file_path": new_file_path}

        return update

    def _collect_tracked_bios_items(self, pending_homes, new_home, bios_files, relocations):
        """Collect tracked BIOS migration items from the ``BiosFile`` snapshot.

        ``bios_files`` is a pre-snapshotted list of ``BiosFile`` records (the
        caller opens the read UoW). Each record's stored path is longest-prefix
        matched against every pending home (#1042), mirroring the ROM records.
        Each item carries a success-hook updater that records the intended new
        ``file_path`` into *relocations* (keyed by the aggregate's composite
        identity ``(platform_slug, file_name)``) when its move/skip succeeds;
        the relocations are applied to ``bios_files`` in a separate write UoW
        after the file moves complete (ADR-0006).
        """
        items = []
        for bios_file in bios_files:
            file_path = bios_file.file_path
            if not file_path:
                continue
            base = match_pending_base(file_path, pending_homes)
            if base is None:
                continue
            new_path = remap_under_current(file_path, base, new_home)
            source = self._resolve_move_source(file_path, base, pending_homes, new_path)
            key = (bios_file.platform_slug, bios_file.file_name)
            items.append(
                (
                    bios_file.file_name,
                    source,
                    new_path,
                    self._make_bios_relocation_updater(relocations, key, new_path),
                    "bios",
                )
            )
        return items

    @staticmethod
    def _make_bios_relocation_updater(relocations, key, new_path):
        """Build a success-hook closure that records one BIOS file's new path.

        The migration loop calls the returned updater once the move (or skip)
        for this BIOS file succeeds. It records the new ``file_path`` keyed by
        the aggregate's composite identity ``(platform_slug, file_name)`` into
        *relocations* so the post-move write UoW can apply ``BiosFile.relocate``
        for each moved record.
        """

        def update():
            relocations[key] = new_path

        return update

    def _collect_untracked_bios_items(self, pending_homes, tracked_file_names):
        """Collect untracked BIOS migration items (downloaded before state tracking).

        ``tracked_file_names`` is the set of BIOS file names already covered by
        the ``BiosFile`` snapshot, so those tracked records aren't moved twice.
        Each registry entry is probed under every pending home's ``bios/`` dir
        newest-first (#1042); the first on-disk hit wins. Untracked BIOS files
        have no aggregate record, so their move carries a no-op updater (nothing
        to persist).
        """
        items = []
        new_bios = self._retrodeck_paths.bios_path()
        for file_name, reg_entry in self._get_bios_files_index().items():
            if file_name in tracked_file_names:
                continue
            firmware_path = reg_entry.get("firmware_path", file_name)
            for home in reversed(pending_homes):
                old_bios = os.path.join(home, "bios")
                if not self._migration_file_store.is_dir(old_bios):
                    continue
                old_file = os.path.join(old_bios, firmware_path)
                if not self._migration_file_store.exists(old_file):
                    continue
                new_file = os.path.join(new_bios, firmware_path)
                items.append((file_name, old_file, new_file, lambda: None, "bios"))
                break
        return items

    def _collect_save_items(self, pending_homes):
        """Collect save file migration items by scanning every pending saves dir.

        Scans ``<home>/saves`` for each pending home (#1042) and deduplicates by
        relative path, newest mtime winning — the same save can exist under
        several homes if the user played while a change was pending, and only
        the freshest copy should survive. Hidden directories (those whose name
        begins with ``.``) and the files they contain are skipped: the RomM
        plugin's ``.romm-backup`` sidecars and any ad-hoc user dotdirs must not
        be migrated.
        """
        new_saves = self._retrodeck_paths.saves_path()
        # rel path -> (source path, mtime); newest mtime wins across homes.
        best: dict[str, tuple[str, float]] = {}
        for home in pending_homes:
            old_saves = os.path.join(home, "saves")
            if not self._migration_file_store.is_dir(old_saves):
                continue
            for dirpath, _dirs, filenames in self._migration_file_store.walk_files(old_saves):
                rel_dir = os.path.relpath(dirpath, old_saves)
                # Skip any descendant of a hidden directory by inspecting the
                # relative-path segments. ``rel_dir == "."`` for the saves
                # root itself, which is never hidden.
                if rel_dir != "." and any(part.startswith(".") for part in rel_dir.split(os.sep)):
                    continue
                for fname in filenames:
                    if fname.startswith("."):
                        continue
                    old_file = os.path.join(dirpath, fname)
                    rel = os.path.relpath(old_file, old_saves)
                    mtime = self._safe_mtime(old_file)
                    existing = best.get(rel)
                    if existing is None or mtime >= existing[1]:
                        best[rel] = (old_file, mtime)
        return [
            (rel, old_file, os.path.join(new_saves, rel), lambda: None, "save")
            for rel, (old_file, _mtime) in best.items()
        ]

    def _safe_mtime(self, path: str) -> float:
        """Return *path*'s mtime, or ``0.0`` when it cannot be read.

        A save file walked one moment can be unreadable the next; a ``0.0``
        fallback keeps that copy in the running for the newest-wins dedupe
        (any readable sibling with a real mtime still wins) rather than
        dropping it or aborting the whole scan.
        """
        try:
            return self._migration_file_store.get_mtime(path)
        except OSError:
            return 0.0

    def _collect_migration_items(self, pending_homes, new_home, installs, bios_files, relocations, bios_relocations):
        """Collect all files that need migration across ROMs, BIOS, and saves.

        Returns list of (label, old_path, new_path, state_update_fn, kind) tuples.
        state_update_fn is called after a successful move/skip to update state.
        ``pending_homes`` is the set of homes a tracked record or on-disk file
        may live under (oldest→newest, current home excluded);
        ``installs``/``bios_files`` are the pre-snapshotted ``RomInstall`` and
        ``BiosFile`` lists; ``relocations`` accumulates the per-``rom_id`` new
        paths and ``bios_relocations`` the per-``(platform_slug, file_name)`` new
        paths for the post-move write UoW.
        """
        tracked_bios_names = {bf.file_name for bf in bios_files}
        items = []
        items.extend(self._collect_rom_items(pending_homes, new_home, installs, relocations))
        items.extend(self._collect_tracked_bios_items(pending_homes, new_home, bios_files, bios_relocations))
        items.extend(self._collect_untracked_bios_items(pending_homes, tracked_bios_names))
        items.extend(self._collect_save_items(pending_homes))
        return items

    def _find_conflicts(self, items):
        """Return sorted list of labels where both source and destination exist."""
        conflict_set = set()
        for label, old_path, new_path, _updater, _kind in items:
            if self._migration_file_store.exists(new_path) and self._migration_file_store.exists(old_path):
                conflict_set.add(label)
        return sorted(conflict_set)

    def _migrate_single_item(self, label, old_path, new_path, state_updater, kind, conflict_strategy, counts, errors):
        """Migrate a single file/directory item. Updates counts and errors in place."""
        # A moved per-ROM directory ("rom_dir") counts as one migrated ROM, same
        # as a single-file ROM ("rom") — both fold into the "rom" counter.
        count_key = "rom" if kind in ("rom", "rom_dir") else kind

        if not self._migration_file_store.exists(old_path):
            if self._migration_file_store.exists(new_path):
                state_updater()
                if count_key:
                    counts[count_key] = counts.get(count_key, 0) + 1
            else:
                # The record's file exists at no known location and no
                # destination — a lost install/BIOS, surfaced in the result
                # so a chained migration never silently reports "nothing to do"
                # while data is gone (#1042).
                counts["missing"] = counts.get("missing", 0) + 1
            return

        if self._migration_file_store.exists(new_path):
            self._migrate_conflict_item(
                label,
                old_path,
                new_path,
                state_updater,
                conflict_strategy,
                count_key,
                counts,
                errors,
            )
            return

        try:
            self._migration_file_store.make_dirs(os.path.dirname(new_path))
            self._migration_file_store.move(old_path, new_path)
            state_updater()
            if count_key:
                counts[count_key] = counts.get(count_key, 0) + 1
            self._logger.info(f"Migrated {kind}: {old_path} -> {new_path}")
        except OSError as e:
            errors.append(f"{label}: {e}")
            self._logger.error(f"Migration failed: {old_path}: {e}")

    def _migrate_conflict_item(
        self,
        label,
        old_path,
        new_path,
        state_updater,
        conflict_strategy,
        count_key,
        counts,
        errors,
    ):
        """Handle migration when destination already exists."""
        if conflict_strategy == "overwrite":
            try:
                if self._migration_file_store.is_dir(new_path):
                    self._migration_file_store.remove_tree(new_path)
                else:
                    self._migration_file_store.remove_file(new_path)
                self._migration_file_store.make_dirs(os.path.dirname(new_path))
                self._migration_file_store.move(old_path, new_path)
                state_updater()
                if count_key:
                    counts[count_key] = counts.get(count_key, 0) + 1
                self._logger.info(f"Migration overwrite: {old_path} -> {new_path}")
            except OSError as e:
                errors.append(f"{label}: {e}")
                self._logger.error(f"Migration overwrite failed: {old_path}: {e}")
        else:
            # skip — keep destination, update state
            state_updater()
            if count_key:
                counts[count_key] = counts.get(count_key, 0) + 1
            self._logger.info(f"Migration skip (exists): {new_path}")

    @staticmethod
    def _build_migration_result(counts, errors):
        """Build the result dict from migration counts and errors.

        ``missing`` (records whose file was found at no known location — see
        ``_migrate_single_item``) is surfaced additively in both the message
        and the ``missing_count`` field so a chained migration reports lost
        files honestly instead of a bare "No files to migrate" success; it does
        not, on its own, make the migration a failure (only ``errors`` do).
        """
        parts = []
        if counts["rom"]:
            parts.append(f"{counts['rom']} ROM(s)")
        if counts["bios"]:
            parts.append(f"{counts['bios']} BIOS")
        if counts["save"]:
            parts.append(f"{counts['save']} save(s)")
        msg = f"Migrated {', '.join(parts)}" if parts else "No files to migrate"
        missing = counts.get("missing", 0)
        if missing:
            msg += f"; {missing} file(s) missing (not found at any known location)"
        if errors:
            msg += f" ({len(errors)} error(s))"
        return {
            "success": len(errors) == 0,
            "message": msg,
            "roms_moved": counts["rom"],
            "bios_moved": counts["bios"],
            "saves_moved": counts["save"],
            "missing_count": missing,
            "errors": errors,
        }

    def _migrate_retrodeck_files_io(self, pending_homes, new_home, conflict_strategy):
        """Sync helper for migrate_retrodeck_files — FS traversal + moves in executor.

        ``pending_homes`` is the full pending set; the current home is filtered
        out defensively so a record already under it is never treated as a move
        source (detection already excludes it, this belts-and-braces that).
        """
        homes = [h for h in pending_homes if h and h != new_home]
        with self._uow_factory() as uow:
            installs = list(uow.rom_installs.iter_all())
            bios_files = list(uow.bios_files.iter_all())
        relocations: dict[int, dict[str, str]] = {}
        bios_relocations: dict[tuple[str, str], str] = {}
        items = self._collect_migration_items(homes, new_home, installs, bios_files, relocations, bios_relocations)
        conflicts = self._find_conflicts(items)

        # If no strategy given and there are conflicts, return them for user decision
        if conflict_strategy is None and conflicts:
            return {
                "success": False,
                "reason": "needs_confirmation",
                "needs_confirmation": True,
                "conflict_count": len(conflicts),
                "conflicts": conflicts,
                "message": f"{len(conflicts)} file(s) already exist at destination",
            }

        counts = {"rom": 0, "bios": 0, "save": 0, "missing": 0}
        errors = []

        for label, old_path, new_path, state_updater, kind in items:
            self._migrate_single_item(
                label,
                old_path,
                new_path,
                state_updater,
                kind,
                conflict_strategy,
                counts,
                errors,
            )

        # Apply the relocations the per-item updaters accumulated and clear the
        # previous-path marker, all in one short write UoW after the file moves.
        self._apply_relocations(installs, relocations, bios_files, bios_relocations, clear_marker=not errors)

        result = self._build_migration_result(counts, errors)
        # Re-resolve the launch command for every installed+bound ROM AFTER the
        # write UoW above has persisted the new paths (ADR-0005/0006): the path
        # is baked into the Steam shortcut's launch_options, so a relocated ROM
        # needs its shortcut rewritten or launches break. Read from a fresh UoW
        # so the relocated rom_installs.file_path is what we build the command
        # from. Stashed on the result for the async caller to emit on the loop.
        result["_relaunch_items"] = self._build_relaunch_items()
        return result

    def _build_relaunch_items(self) -> list[dict[str, Any]]:
        """Build the ``migration_relaunch_options`` items from the post-move state.

        Delegates to the shared ``relaunch_options`` resolver: it re-bakes every
        installed+bound ROM's Steam ``launch_options`` from the relocated path
        (active core + selected disc), snapshotting the rows in one short read
        UoW it closes before resolving so the nested resolver UoW never deadlocks
        (#1154). Called after ``_apply_relocations`` has persisted the new paths,
        so the items carry the relocated ``file_path``.
        """
        return self._relaunch_options.installed_relaunch_items()

    def _apply_relocations(self, installs, relocations, bios_files, bios_relocations, *, clear_marker):
        """Persist the relocated install and BIOS records (and optionally clear the markers).

        Opens a single write UoW after the file moves: for every install whose
        move/skip succeeded, calls ``RomInstall.relocate`` with the new
        ``rom_dir`` (``None`` for a single-file ROM) and ``file_path``; for every
        BIOS record whose move/skip succeeded, calls ``BiosFile.relocate`` with
        the new ``file_path``. Both are saved in the same transaction. When
        *clear_marker* is true (a fully-successful migration) the pending-home
        markers — ``retrodeck_home_path_previous`` **and** every hop — are
        deleted in the same transaction.
        """
        by_id = {install.rom_id: install for install in installs}
        by_key = {(bf.platform_slug, bf.file_name): bf for bf in bios_files}
        with self._uow_factory() as uow:
            for rom_id, moved in relocations.items():
                install = by_id.get(rom_id)
                if install is None:
                    continue
                install.relocate(moved["rom_dir"], moved["file_path"])
                uow.rom_installs.save(install)
            for key, new_path in bios_relocations.items():
                bios_file = by_key.get(key)
                if bios_file is None:
                    continue
                bios_file.relocate(new_path)
                uow.bios_files.save(bios_file)
            if clear_marker:
                self._write_pending_homes(uow, [])

    async def migrate_retrodeck_files(self, conflict_strategy=None):
        """Move downloaded ROMs, BIOS, and save files from old RetroDECK path to new.

        Args:
            conflict_strategy: None to scan and return conflicts, "overwrite" to
                replace existing destination files, "skip" to keep existing files
                and just update state paths.
        """
        with self._uow_factory() as uow:
            pending = self._read_pending_homes(uow)
            new_home = uow.kv_config.get(_KV_RETRODECK_HOME) or ""

        if not pending or not new_home:
            return {"success": False, "reason": "no_migration_needed", "message": "No path migration needed"}

        result = await self._loop.run_in_executor(
            None, self._migrate_retrodeck_files_io, pending, new_home, conflict_strategy
        )
        # Pop the internal relaunch payload (only present on the actual-migration
        # path, not the needs-confirmation early return) and emit it so the live
        # Steam shortcuts get their baked launch_options rewritten to the new
        # paths. Emitted after the executor returns — the relocation write UoW
        # has already committed, so the items carry the persisted new paths.
        relaunch_items = result.pop("_relaunch_items", None)
        if relaunch_items is not None:
            await self._emit("migration_relaunch_options", {"items": relaunch_items})
            # Record each re-baked command as the shortcut's applied state (the
            # value the frontend confirm-sets onto the relocated shortcut), so the
            # next sync skips the now-correct shortcut instead of re-touching it
            # (delta apply, #1383). Fifth of the six recorded-state writer sites.
            await self._loop.run_in_executor(None, self._record_migration_applied_io, relaunch_items)
        return result

    def _record_migration_applied_io(self, items: list[dict[str, Any]]) -> None:
        """Record each relaunch item's ``launch_options`` as its ROM's applied state.

        The relaunch items are keyed by ``app_id``; each is resolved back to its
        bound ROM (``get_by_app_id``) and its recorded ``applied_launch_options``
        set to the re-baked command, in one short write UoW. A missing binding
        (shortcut removed between the re-bake and here) is skipped.
        """
        with self._uow_factory() as uow:
            for item in items:
                rom = uow.roms.get_by_app_id(int(item["app_id"]))
                if rom is not None:
                    rom.record_applied_launch_options(item["launch_options"])
                    uow.roms.set_applied_launch_options(rom.rom_id, rom.applied_launch_options)

    def _get_migration_status_io(self, pending, new_home):
        """Sync helper for get_migration_status — FS traversal in executor.

        ``old_path`` reports the oldest pending home (``pending[0]``), so the
        banner still reads "From: A → To: C" across a chained pending set.
        """
        homes = [h for h in pending if h and h != new_home]
        with self._uow_factory() as uow:
            installs = list(uow.rom_installs.iter_all())
            bios_files = list(uow.bios_files.iter_all())
        items = self._collect_migration_items(homes, new_home, installs, bios_files, {}, {})
        roms_count = sum(1 for _, _, _, _, kind in items if kind in ("rom", "rom_dir"))
        bios_count = sum(1 for _, _, _, _, kind in items if kind == "bios")
        saves_count = sum(1 for _, _, _, _, kind in items if kind == "save")

        return {
            "pending": True,
            "old_path": pending[0],
            "new_path": new_home,
            "roms_count": roms_count,
            "bios_count": bios_count,
            "saves_count": saves_count,
        }

    async def get_migration_status(self):
        """Return whether a RetroDECK path migration is pending and file counts."""
        with self._uow_factory() as uow:
            pending = self._read_pending_homes(uow)
            new_home = uow.kv_config.get(_KV_RETRODECK_HOME) or ""

        if not pending or not new_home:
            return {"pending": False}

        return await self._loop.run_in_executor(None, self._get_migration_status_io, pending, new_home)

    # ---------------------------------------------------------------------------
    # Save sort change detection and migration
    # ---------------------------------------------------------------------------

    @staticmethod
    def _read_save_sort_settings(uow) -> SaveSortSettings | None:
        """Decode the last-seen save-sort observation from kv_config, ``None`` when absent."""
        raw = uow.kv_config.get(_KV_SAVE_SORT)
        return json.loads(raw) if raw is not None else None

    @staticmethod
    def _read_save_sort_settings_previous(uow) -> SaveSortSettings | None:
        """Decode the pending pre-change save-sort snapshot from kv_config, ``None`` when absent."""
        raw = uow.kv_config.get(_KV_SAVE_SORT_PREVIOUS)
        return json.loads(raw) if raw is not None else None

    def detect_save_sort_change(self) -> SaveLayout:
        """Refresh save-sort state from the live RetroArch config; return the layout.

        Reads the live ``SaveLayout`` and returns it so the SyncEngine can
        hard-gate save sync when it is ``ContentDir`` (#239). When the
        layout is ``ContentDir`` the kv_config save-sort change-detection
        markers are never touched — content-dir saves live next to the ROM,
        outside the saves tree the plugin syncs, so there is no sort layout
        to migrate. A single per-process warning is logged so the unsupported
        state is visible without spamming every sync.

        For the supported ``InSaveDir`` case, runs the cross-run change
        detection against the stored observation, writing the
        ``_KV_SAVE_SORT`` / ``_KV_SAVE_SORT_PREVIOUS`` markers and emitting
        ``save_sort_changed`` when the layout flips (#238).

        May be called from a worker thread (via
        ``SyncEngine._refresh_save_sort_state`` → ``run_in_executor``) or
        from the loop thread. Use ``asyncio.run_coroutine_threadsafe`` to
        schedule the emit coroutine: it is explicitly thread-safe and
        also works correctly when invoked from the loop thread itself.
        ``loop.create_task`` is NOT thread-safe and races with loop
        internals on CPython (#238 review).
        """
        layout = self._get_save_layout()
        if isinstance(layout, ContentDir):
            if not self._content_dir_warned:
                self._logger.warning(
                    "RetroArch savefiles_in_content_dir is enabled — saves are written "
                    "next to the ROM, so plugin save sync is unsupported and is disabled."
                )
                self._content_dir_warned = True
        else:
            self._detect_in_save_dir_change(layout)
        return layout

    def _detect_in_save_dir_change(self, layout: InSaveDir) -> None:
        """Run the cross-run save-sort change detection for a supported ``InSaveDir`` layout.

        Records the current sort settings as the ``_KV_SAVE_SORT`` observation; when they
        differ from the stored one, sets the ``_KV_SAVE_SORT_PREVIOUS`` pending-migration
        marker and emits ``save_sort_changed`` so the frontend can offer the migration (#238).
        """
        current: SaveSortSettings = {"sort_by_content": layout.sort_by_content, "sort_by_core": layout.sort_by_core}
        if sys.platform == "win32":
            with self._uow_factory() as uow:
                if not uow.kv_config.get(_KV_WINDOWS_SAVE_SORT_RESEEDED):
                    # Windows builds before 0.33.0-win.6 could not read EmuDeck's
                    # retroarch.cfg and recorded RetroDECK's default sorting. That
                    # marker never described this machine, so replace it once
                    # instead of treating the real layout as a user change.
                    uow.kv_config.set(_KV_SAVE_SORT, json.dumps(current))
                    uow.kv_config.delete(_KV_SAVE_SORT_PREVIOUS)
                    uow.kv_config.set(_KV_WINDOWS_SAVE_SORT_RESEEDED, "1")
                    return
        with self._uow_factory() as uow:
            stored = self._read_save_sort_settings(uow)
        if stored is None:
            with self._uow_factory() as uow:
                uow.kv_config.set(_KV_SAVE_SORT, json.dumps(current))
            return
        if stored == current:
            return
        with self._uow_factory() as uow:
            uow.kv_config.set(_KV_SAVE_SORT_PREVIOUS, json.dumps(stored))
            uow.kv_config.set(_KV_SAVE_SORT, json.dumps(current))
        self._logger.warning(f"RetroArch save sorting changed: {stored} -> {current}")
        # Fire-and-forget: thread-safe schedule of the emit coroutine on
        # the plugin event loop. We deliberately do not await or .result()
        # the future — this mirrors the previous create_task semantics.
        asyncio.run_coroutine_threadsafe(
            self._emit(
                "save_sort_changed",
                {"old_settings": stored, "new_settings": current},
            ),
            self._loop,
        )

    def _resolve_retroarch_corename(self, rom_id: int) -> tuple[str | None, str | None]:
        """Resolve the RetroArch save subdirectory name for a ROM by ``rom_id``.

        Asks the per-ROM ``ActiveCoreReader`` **which** core is active (the
        per-game ``emulator_override`` pin folded over the system default),
        then asks the RetroArch ``.info`` parser (via ``get_core_name``)
        **what** RetroArch calls that core in its own subsystem — which
        is what ``sort_savefiles_enable`` uses when naming save
        subdirectories.

        Returns a ``(corename, core_so)`` tuple. ``corename`` is ``None``
        (fail loud, no ES-DE label fallback) when the resolver cannot
        resolve a core for this ROM. ``core_so`` is the underlying
        ES-DE core ``.so`` basename when known (useful for diagnostics
        when ``corename`` is ``None``), otherwise ``None``.
        """
        core_so, _label = self._active_core.active_core_for_rom(rom_id)
        if not core_so:
            return (None, None)
        corename = self._get_core_name(core_so)
        return (corename or None, core_so)

    def _collect_save_sorting_items(
        self,
        old_settings: SaveSortSettings,
        new_settings: SaveSortSettings,
        installs: list[RomInstall],
    ) -> list[tuple[str, str, str, object, str]]:
        """Collect save files that need migration due to sort setting change.

        ``installs`` is the pre-snapshotted ``RomInstall`` list (the caller opens
        the read UoW); this method is pure compute over it.
        """
        saves_base = self._retrodeck_paths.saves_path()
        roms_base = self._retrodeck_paths.roms_path()
        need_core = bool(old_settings.get("sort_by_core") or new_settings.get("sort_by_core"))
        items: list[tuple[str, str, str, object, str]] = []
        for install in installs:
            self._collect_rom_sort_items(
                install,
                saves_base,
                roms_base,
                old_settings,
                new_settings,
                need_core,
                items,
            )
        return items

    def _collect_rom_sort_items(
        self,
        install: RomInstall,
        saves_base: str,
        roms_base: str,
        old_settings: SaveSortSettings,
        new_settings: SaveSortSettings,
        need_core: bool,
        items: list[tuple[str, str, str, object, str]],
    ) -> None:
        """Collect migration items for a single ROM's save files."""
        system = install.system
        file_path = install.file_path
        if not system or not file_path:
            return
        core_name: str | None = None
        if need_core:
            core_name, core_so = self._resolve_retroarch_corename(install.rom_id)
            if core_name is None:
                # Fail loud — cannot resolve the RetroArch corename for this ROM's
                # active core, so we can't build the correct sort-by-core path.
                # Skip this item and warn the user rather than silently corrupting
                # the migration with the wrong destination directory.
                self._logger.warning(
                    "Skipping save sort migration for %s/%s: unable to resolve "
                    "RetroArch corename from .info (core_so=%s)",
                    system,
                    os.path.basename(file_path),
                    core_so,
                )
                return
        old_dir = resolve_save_dir(
            file_path,
            saves_base,
            system,
            roms_base=roms_base,
            sort_by_content=old_settings["sort_by_content"],
            sort_by_core=old_settings["sort_by_core"],
            core_name=core_name,
        )
        new_dir = resolve_save_dir(
            file_path,
            saves_base,
            system,
            roms_base=roms_base,
            sort_by_content=new_settings["sort_by_content"],
            sort_by_core=new_settings["sort_by_core"],
            core_name=core_name,
        )
        if old_dir == new_dir:
            return
        rom_name = os.path.splitext(os.path.basename(file_path))[0]
        for ext in get_save_extensions(system):
            filename = rom_name + ext
            old_file = os.path.join(old_dir, filename)
            new_file = os.path.join(new_dir, filename)
            if self._migration_file_store.exists(old_file):
                items.append((filename, old_file, new_file, lambda: None, "save"))

    def _get_save_sort_migration_status_io(
        self, old_settings: SaveSortSettings, new_settings: SaveSortSettings
    ) -> dict[str, Any]:
        with self._uow_factory() as uow:
            installs = list(uow.rom_installs.iter_all())
        items = self._collect_save_sorting_items(old_settings, new_settings, installs)
        return {
            "pending": True,
            "old_settings": old_settings,
            "new_settings": new_settings,
            "saves_count": len(items),
        }

    def dismiss_save_sort_migration(self) -> dict[str, Any]:
        """Dismiss the save sort migration warning without migrating files."""
        with self._uow_factory() as uow:
            uow.kv_config.delete(_KV_SAVE_SORT_PREVIOUS)
        return {"success": True}

    async def get_save_sort_migration_status(self) -> dict[str, Any]:
        with self._uow_factory() as uow:
            old = self._read_save_sort_settings_previous(uow)
            new = self._read_save_sort_settings(uow)
        if not old or not new or old == new:
            return {"pending": False}
        return await self._loop.run_in_executor(None, self._get_save_sort_migration_status_io, old, new)

    async def refresh_state(self) -> dict[str, Any]:
        """Run both detection passes and return combined migration state.

        Detects any RetroDECK home-path change and any RetroArch save-sort
        change, then returns the current status of both migrations.
        """
        self.detect_retrodeck_path_change()
        self.detect_save_sort_change()
        return {
            "retrodeck": await self.get_migration_status(),
            "save_sort": await self.get_save_sort_migration_status(),
        }

    def _resolve_save_sort_conflict(
        self,
        label: str,
        old_path: str,
        new_path: str,
        state_updater,
        counts: dict[str, int],
        count_key: str,
        errors: list[str],
    ) -> None:
        """Newest-wins resolution for a save-sort conflict.

        RetroArch does not migrate saves when its sort setting changes. If a
        user flips ``sort_savefiles_enable`` mid-game via the Quick Menu and
        then saves in-game, the new progress is written to the new layout
        while the old location still holds pre-change content. The file at
        the newer mtime contains actual user progress; the older one is
        stale and must be cleaned up. Save-sync has already uploaded the
        newest version to RomM before this runs, so even if local migration
        fails the server still holds the authoritative copy.
        """
        try:
            old_mtime = self._migration_file_store.get_mtime(old_path)
            new_mtime = self._migration_file_store.get_mtime(new_path)
        except OSError as e:
            errors.append(f"{label}: {e}")
            self._logger.error(f"Save-sort conflict mtime read failed: {old_path}: {e}")
            return

        if new_mtime >= old_mtime:
            # Destination is newer — keep it, delete the stale orphan at old_path.
            try:
                self._migration_file_store.remove_file(old_path)
                state_updater()
                counts[count_key] = counts.get(count_key, 0) + 1
                self._logger.info(f"Save-sort conflict: kept newer {new_path}, removed stale {old_path}")
            except OSError as e:
                errors.append(f"{label}: {e}")
                self._logger.error(f"Save-sort orphan cleanup failed: {old_path}: {e}")
            return

        # Source is newer — atomically overwrite destination.
        try:
            self._migration_file_store.make_dirs(os.path.dirname(new_path))
            self._migration_file_store.rename(old_path, new_path)
            state_updater()
            counts[count_key] = counts.get(count_key, 0) + 1
            self._logger.info(f"Save-sort conflict: moved newer {old_path} -> {new_path}")
        except OSError as e:
            errors.append(f"{label}: {e}")
            self._logger.error(f"Save-sort overwrite failed: {old_path}: {e}")

    def _migrate_save_sort_files_io(
        self, old_settings: SaveSortSettings, new_settings: SaveSortSettings, conflict_strategy: str | None
    ) -> dict[str, Any]:
        # conflict_strategy is retained for backwards-compatibility with the
        # callable signature but is unused for save-sort migration — conflicts
        # are resolved in place via newest-wins (see _resolve_save_sort_conflict).
        del conflict_strategy
        with self._uow_factory() as uow:
            installs = list(uow.rom_installs.iter_all())
        items = self._collect_save_sorting_items(old_settings, new_settings, installs)
        if not items:
            with self._uow_factory() as uow:
                uow.kv_config.delete(_KV_SAVE_SORT_PREVIOUS)
            return {"success": True, "message": "No save files to migrate", "saves_moved": 0}
        counts: dict[str, int] = {"rom": 0, "bios": 0, "save": 0}
        errors: list[str] = []
        for label, old_path, new_path, updater, _kind in items:
            if self._migration_file_store.exists(old_path) and self._migration_file_store.exists(new_path):
                self._resolve_save_sort_conflict(label, old_path, new_path, updater, counts, "save", errors)
            else:
                self._migrate_single_item(label, old_path, new_path, updater, "save", None, counts, errors)
        if not errors:
            with self._uow_factory() as uow:
                uow.kv_config.delete(_KV_SAVE_SORT_PREVIOUS)
        return self._build_migration_result(counts, errors)

    async def migrate_save_sort_files(self, conflict_strategy: str | None = None) -> dict[str, Any]:
        with self._uow_factory() as uow:
            old = self._read_save_sort_settings_previous(uow)
            new = self._read_save_sort_settings(uow)
        if not old or not new or old == new:
            return {"success": False, "reason": "no_migration_needed", "message": "No save sorting migration needed"}
        return await self._loop.run_in_executor(None, self._migrate_save_sort_files_io, old, new, conflict_strategy)
